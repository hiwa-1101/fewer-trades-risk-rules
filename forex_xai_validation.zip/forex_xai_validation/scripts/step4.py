"""Step 4: cost-aware logistic filter, scale-free SRD robustness, economic translation, auditable example rule."""
import sys, json, warnings
import os
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0, S + 'scripts'); sys.argv = ['x']
import robustness as rb
rng = np.random.default_rng(5)
OUT = {}

def prep(f, train_end='2025-01-01'):
    d = pd.read_csv(S + f, parse_dates=['open_time'])
    tr = (d.open_time < train_end).values
    q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
    d['y'] = (d.outcome == 'SL').astype(int); d['R'] = d.net_pips / d.sl_pips
    return d

def block_diff_ci(d_acc, d_all, B=4000):
    # day-block bootstrap of (mean R accepted - mean R all) on the test year
    day = d_all.open_time.dt.normalize().values; days, inv = np.unique(day, return_inverse=True)
    acc = d_all.index.isin(d_acc.index)
    s_all = np.bincount(inv, weights=d_all.R.values); n_all = np.bincount(inv)
    s_acc = np.bincount(inv, weights=d_all.R.values * acc); n_acc = np.bincount(inv, weights=acc.astype(float))
    out = []
    for _ in range(B):
        i = rng.integers(0, len(days), len(days))
        if n_acc[i].sum() == 0: continue
        out.append(s_acc[i].sum() / n_acc[i].sum() - s_all[i].sum() / n_all[i].sum())
    return [round(np.percentile(out, 2.5), 3), round(np.percentile(out, 97.5), 3)]

# ---- (a) cost-aware logistic decision filter
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    d = prep(f); X = pd.get_dummies(d[rb.F].astype(str)).astype(int)
    y23, y24, y25 = (d.open_time.dt.year == 2023).values, (d.open_time.dt.year == 2024).values, (d.open_time.dt.year == 2025).values
    # choose rejection share on 2024 using a model trained on 2023
    m1 = LogisticRegression(max_iter=3000).fit(X[y23], d.y[y23])
    p24 = m1.predict_proba(X[y24])[:, 1]; R24 = d.R[y24].values
    best = (0.0, R24.mean())
    for share in [0.1, 0.2, 0.3, 0.4, 0.5]:
        thr = np.quantile(p24, 1 - share); acc = p24 < thr
        if R24[acc].mean() > best[1]: best = (share, R24[acc].mean())
    share = best[0]
    # refit on 2023-24, apply same rejection share (quantile of training scores) to 2025
    tr = y23 | y24
    m2 = LogisticRegression(max_iter=3000).fit(X[tr], d.y[tr])
    ptr = m2.predict_proba(X[tr])[:, 1]; p25 = m2.predict_proba(X[y25])[:, 1]
    thr = np.quantile(ptr, 1 - share) if share > 0 else np.inf
    test = d[y25].copy(); acc = p25 < thr
    res = dict(chosen_reject_share=share, val_2024_R_unfiltered=round(R24.mean(), 3), val_2024_R_filtered=round(best[1], 3),
               test_reject_share=round(1 - acc.mean(), 3), test_R_unfiltered=round(test.R.mean(), 3),
               test_R_accepted=round(test.R[acc].mean(), 3), test_loss_unfiltered=round(test.y.mean(), 3),
               test_loss_accepted=round(test.y[acc].mean(), 3), test_auc=round(roc_auc_score(test.y, p25), 3))
    res['diff_ci_block'] = block_diff_ci(test[acc], test) if share > 0 else [0, 0]
    OUT.setdefault('logit_filter', {})[name] = res

# ---- (b) scale-free SRD: near = lowest training tertile of nearest-level distance within pair x timeframe
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    d = prep(f); tr = (d.open_time < '2025').values
    res_ = d.res_dist_pips.where(d.res_dist_pips >= 0, np.inf); sup_ = d.sup_dist_pips.where(d.sup_dist_pips >= 0, np.inf)
    mind = np.minimum(res_, sup_)
    cut = d[tr].assign(m=mind[tr]).groupby(['pair', 'timeframe']).m.quantile(1 / 3)
    c = d.set_index(['pair', 'timeframe']).index.map(cut).values
    d['SRD'] = np.where(mind <= c, np.where(res_ <= sup_, 'R', 'S'), 'N')
    I = pd.get_dummies(d[rb.F].astype(str), prefix_sep='=').astype(bool)
    A = rb.artifacts(I[tr].reset_index(drop=True), d.y.values[tr], (d.pair + d.timeframe)[tr].values)
    rules = rb.xai_rules(A, 1.10, 0.10, 2); apr = rb.xai_rules(A, 1.10, 0.10, 2, use_cart=False)
    lr = LogisticRegression(max_iter=3000).fit(I[tr].astype(int), d.y[tr])
    OUT.setdefault('srd_scale_free', {})[name] = dict(srd_dist=d.SRD.value_counts(normalize=True).round(3).to_dict(),
        apriori_candidates=len(apr), final_rules=len(rules),
        test_auc_logit=round(roc_auc_score(d.y[~tr], lr.predict_proba(I[~tr].astype(int))[:, 1]), 3))

# ---- (c) economic translation (reversal, fixed 1.5R target)
d = prep('mw_all.csv')
win, loss = d[d.y == 0].R.mean(), d[d.y == 1].R.mean(); L0 = d.y.mean()
wstar = -loss / (win - loss)          # win rate needed for zero mean net R given observed average win/loss R
OUT['economics_reversal'] = dict(avg_win_R=round(win, 3), avg_loss_R=round(loss, 3), loss_rate=round(L0, 3),
                                 breakeven_loss_rate=round(1 - wstar, 3), required_reduction_pp=round((L0 - (1 - wstar)) * 100, 2))
# what a detectable rule (coverage c, excess loss delta) does to accepted loss rate
def accepted_loss(L0, cov, delta):
    pS = L0 + delta; return (L0 - cov * pS) / (1 - cov)
OUT['economics_reversal']['accepted_loss_cov8_d20'] = round(accepted_loss(L0, 0.08, 0.20), 4)
OUT['economics_reversal']['required_delta_at_cov10'] = round(((L0 - (1 - wstar)) * (1 - 0.10)) / 0.10, 3)
dt = prep('tf_all.csv')
OUT['economics_trend'] = dict(mean_R=round(dt.R.mean(), 3), avg_win_R=round(dt[dt.y == 0].R.mean(), 3),
                              avg_loss_R=round(dt[dt.y == 1].R.mean(), 3), loss_rate=round(dt.y.mean(), 3))

# ---- (d) auditable example rule from the positive control
d, I, tr = rb.load('mw_all.csv'); y = d.y.values.copy(); r_ = np.random.default_rng(7)
conj = ('PP=Upper', 'CSC=Low'); inC = rb.covers(I, conj); pC = y[inC & tr].mean()
y[inC & (y == 0) & (r_.random(len(y)) < 0.20 / (1 - pC))] = 1
Xtr = I[tr].reset_index(drop=True); A = rb.artifacts(Xtr, y[tr], (d.pair + d.timeframe)[tr].values)
rules = rb.xai_rules(A, 1.10, 0.10, 2)
ex = []
for r in rules:
    m = rb.covers(Xtr, r); leafs = pd.Series(A['leaf'][m]).value_counts(normalize=True)
    ex.append(dict(rule=' AND '.join(sorted(r)), support=round(m.mean(), 3), confidence=round(y[tr][m].mean(), 3),
                   base=round(y[tr].mean(), 3), partitions=sorted(A['part_conf'][frozenset(r)].keys()) if frozenset(r) in A['part_conf'] else None,
                   main_leaf_loss=round(A['pur'][leafs.index[0]], 3), share_in_main_leaf=round(leafs.iloc[0], 3),
                   planted=' AND '.join(conj), pC_before=round(pC, 3)))
OUT['example_rule'] = ex
json.dump(OUT, open(S + 'results/step4.json', 'w'), indent=1, default=str)
print(json.dumps(OUT, indent=1, default=str))
