#!/usr/bin/env python3
"""
Reproducible analysis for:
"Explainable Association-Rule Mining for Pre-Trade Stop-Loss Risk Detection in Forex Reversal Patterns"

Input : one CSV with ONE ROW PER REAL TRADE (no augmented rows), columns:
  open_time   e.g. 2024-03-05 14:35   (breakout-candle close time)
  pair        EURUSD | GBPUSD | USDJPY
  timeframe   M5 | M15 | H1
  pattern     M | W
  PP SRD VR PC TL CSC UDF MMD   discretized labels as in Table I (e.g. PP=Upper, TL=UDU, UDF=High)
  outcome     SL | TP
  net_pips    realized pips AFTER spread + commission (negative for SL)

Usage : python3 forex_rule_analysis.py trades.csv  [--test-start 2025-01-01]
Output: results.md (tables for the paper), rules.csv (final rule base), results.json

Requires: pip install pandas numpy scipy scikit-learn mlxtend
"""
import argparse, json, itertools
import numpy as np, pandas as pd
from scipy.stats import wilcoxon, norm
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from mlxtend.frequent_patterns import apriori

FEATS = ['PP', 'SRD', 'VR', 'PC', 'TL', 'CSC', 'UDF', 'MMD']
ap = argparse.ArgumentParser()
ap.add_argument('csv'); ap.add_argument('--test-start', default='2025-01-01')
ap.add_argument('--min-sup', type=float, default=0.05); ap.add_argument('--min-conf', type=float, default=0.60)
ap.add_argument('--leaf-purity', type=float, default=0.75); ap.add_argument('--jaccard', type=float, default=0.80)
ap.add_argument('--min-partitions', type=int, default=2); ap.add_argument('--random-runs', type=int, default=1000)
ap.add_argument('--boot', type=int, default=10000); ap.add_argument('--seed', type=int, default=42)
ap.add_argument('--relative', action='store_true', help='min_conf = 1.1 x training base SL rate; leaf purity = base + 0.10')
a = ap.parse_args(); rng = np.random.default_rng(a.seed)

df = pd.read_csv(a.csv, parse_dates=['open_time']).sort_values('open_time').reset_index(drop=True)
df['y'] = (df['outcome'].str.upper() == 'SL').astype(int)
# MMD: the pattern detector already requires height >= 1 x ATR, so a fixed threshold of 1.0
# makes MMD constant. Re-discretize from the raw value using TRAINING-set tertiles (no leakage).
MMD_CUTS = None
if 'mmd_raw' in df.columns:
    _tr = df['open_time'] < pd.Timestamp(a.test_start)
    q1, q2 = df.loc[_tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    df['MMD'] = np.where(df['mmd_raw'] < q1, 'Low', np.where(df['mmd_raw'] > q2, 'High', 'Middle'))
    MMD_CUTS = [round(float(q1), 3), round(float(q2), 3)]
items = pd.get_dummies(df[FEATS].astype(str), prefix_sep='=').astype(bool)
train = df['open_time'] < pd.Timestamp(a.test_start); test = ~train
Xtr, Xte, ytr = items[train], items[test], df.loc[train, 'y']
if a.relative:
    a.min_conf = max(a.min_conf, 1.1 * ytr.mean()); a.leaf_purity = min(0.95, ytr.mean() + 0.10)
    print(f'relative thresholds: min_conf={a.min_conf:.3f}  leaf_purity={a.leaf_purity:.3f}')

def covers(X, ante):
    m = np.ones(len(X), bool)
    for it in ante: m &= X[it].values
    return m

# ---------- 1) Apriori per partition (class association rules X -> SL) ----------
strata = df.loc[train, 'pair'].astype(str) + '_' + df.loc[train, 'timeframe'].astype(str)
skf = StratifiedKFold(n_splits=8, shuffle=True, random_state=a.seed)
cand = {}  # antecedent -> set(partitions)
for k, (_, idx) in enumerate(skf.split(Xtr, strata), 1):
    T = Xtr.iloc[idx].copy(); T['CLASS=SL'] = ytr.iloc[idx].values.astype(bool)
    fi = apriori(T, min_support=a.min_sup, use_colnames=True)
    sup = {frozenset(s): v for s, v in zip(fi['itemsets'], fi['support'])}
    for s, v in sup.items():
        if 'CLASS=SL' in s and len(s) > 1:
            ante = s - {'CLASS=SL'}
            if ante in sup and v / sup[ante] >= a.min_conf:
                cand.setdefault(frozenset(ante), set()).add(k)
apriori_rules = {r: p for r, p in cand.items() if len(p) >= a.min_partitions}

# ---------- 2) CART validation ----------
gs = GridSearchCV(DecisionTreeClassifier(random_state=a.seed, class_weight=None),
                  {'max_depth': [3, 4, 5, 6, 8], 'min_samples_leaf': [20, 40, 80]}, cv=10, scoring='roc_auc')
gs.fit(Xtr.values, ytr.values); tree = gs.best_estimator_
leaf_tr = tree.apply(Xtr.values)
purity = pd.Series(ytr.values).groupby(leaf_tr).mean()
risky_leaves = set(purity[purity > a.leaf_purity].index)
in_risky = np.isin(leaf_tr, list(risky_leaves))
def cart_ok(ante):
    m = covers(Xtr, ante)
    return m.sum() > 0 and in_risky[m].mean() >= 0.5   # majority of covered events lie in high-risk leaves
hybrid = {r: p for r, p in apriori_rules.items() if cart_ok(r)}

# ---------- 3) Jaccard consolidation ----------
rules = dict(hybrid); changed = True
while changed:
    changed = False
    for r1, r2 in itertools.combinations(list(rules), 2):
        if r1 in rules and r2 in rules and len(r1 | r2) and len(r1 & r2) / len(r1 | r2) >= a.jaccard:
            g = r1 & r2; parts = rules.pop(r1) | rules.pop(r2)
            rules[g] = rules.get(g, set()) | parts; changed = True; break

def stats(ante, X, y):
    m = covers(X, ante); n = m.sum()
    return n, (y[m].mean() if n else np.nan), n / len(X)
rows = []
for r, p in sorted(rules.items(), key=lambda kv: -stats(kv[0], Xtr, ytr.values)[1]):
    n, conf, sup = stats(r, Xtr, ytr.values)
    rows.append({'rule': ' AND '.join(sorted(r)), 'train_cover': int(n), 'train_support': round(sup, 4),
                 'train_conf': round(conf, 4), 'class': 'conservative (conf=1, no TP blocked)' if conf == 1 else 'adaptive',
                 'partitions': ','.join(f'P{i}' for i in sorted(p))})
pd.DataFrame(rows).to_csv('rules.csv', index=False)

# ---------- 4) filters on the out-of-sample test set ----------
te = df[test].reset_index(drop=True); Xt = Xte.reset_index(drop=True)
def rule_mask(rs):
    m = np.zeros(len(Xt), bool)
    for r in rs: m |= covers(Xt, r)
    return m
single = max(((it,) for it in Xtr.columns), key=lambda r: (stats(r, Xtr, ytr.values)[1] if stats(r, Xtr, ytr.values)[2] >= a.min_sup else 0))
masks = {
    'Unfiltered': np.zeros(len(te), bool),
    f'Single-indicator ({single[0]})': rule_mask([frozenset(single)]),
    'Apriori-only': rule_mask(apriori_rules),
    'CART-only': np.isin(tree.apply(Xt.values), list(risky_leaves)),
    'Hybrid Apriori-CART (proposed)': rule_mask(rules),
}
def metrics(rej):
    t = te[~rej]; p = t['net_pips']; cum = p.cumsum()
    sl, tp = int(t['y'].sum()), int((1 - t['y']).sum())
    return {'taken': len(t), 'rejected': int(rej.sum()), 'SL': sl, 'TP': tp,
            'TP_lost': int((te['y'][rej] == 0).sum()), 'SL_avoided': int(te['y'][rej].sum()),
            'SL_rate_%': round(100 * sl / max(len(t), 1), 2), 'win_rate_%': round(100 * tp / max(len(t), 1), 2),
            'net_PF': round(p[p > 0].sum() / max(-p[p < 0].sum(), 1e-9), 3), 'net_pips': round(p.sum(), 1),
            'max_DD_pips': round((cum.cummax() - cum).max() if len(cum) else 0, 1), 'expectancy_pips': round(p.mean(), 3)}
res = {k: metrics(m) for k, m in masks.items()}

# random filter with identical rejection count
k_rej = int(masks['Hybrid Apriori-CART (proposed)'].sum())
rand = [metrics(np.isin(np.arange(len(te)), rng.choice(len(te), k_rej, replace=False))) for _ in range(a.random_runs)]
res[f'Random filter (mean of {a.random_runs})'] = {k: round(float(np.mean([r[k] for r in rand])), 3) for k in rand[0]}
prop = res['Hybrid Apriori-CART (proposed)']
p_rand_SL = float(np.mean([r['SL'] <= prop['SL'] for r in rand]))       # permutation p (one-sided)
p_rand_pips = float(np.mean([r['net_pips'] >= prop['net_pips'] for r in rand]))

# ---------- 5) statistics ----------
day = te['open_time'].dt.normalize()
d_base = te.groupby(day)['net_pips'].sum()
d_prop = te[~masks['Hybrid Apriori-CART (proposed)']].groupby(day[~masks['Hybrid Apriori-CART (proposed)']])['net_pips'].sum().reindex(d_base.index, fill_value=0)
diff = (d_prop - d_base); nz = int((diff != 0).sum())
if nz >= 6:
    w = wilcoxon(d_prop, d_base, zero_method='wilcox', alternative='two-sided')
    mu, sd = nz * (nz + 1) / 4, np.sqrt(nz * (nz + 1) * (2 * nz + 1) / 24)
    z = (w.statistic - mu) / sd
    wil = {'paired_unit': 'daily net pips', 'n_days': len(diff), 'n_nonzero': nz, 'W': float(w.statistic),
           'Z': round(float(z), 3), 'p': float(w.pvalue), 'effect_r': round(abs(float(z)) / np.sqrt(nz), 3)}
else:
    wil = {'note': 'too few non-zero paired days for Wilcoxon'}
boot_sl, boot_np = [], []
y, pip, rej = te['y'].values, te['net_pips'].values, masks['Hybrid Apriori-CART (proposed)']
for _ in range(a.boot):
    i = rng.integers(0, len(te), len(te))
    sl0 = y[i].sum(); sl1 = y[i][~rej[i]].sum(); n0 = pip[i].sum(); n1 = pip[i][~rej[i]].sum()
    if sl0 > 0: boot_sl.append(100 * (sl0 - sl1) / sl0)
    if n0 != 0: boot_np.append(100 * (n1 - n0) / abs(n0))
ci = lambda v: [round(float(np.percentile(v, 2.5)), 2), round(float(np.percentile(v, 97.5)), 2)]
base = res['Unfiltered']
summary = {
    'min_conf_used': round(a.min_conf, 3), 'leaf_purity_used': round(a.leaf_purity, 3),
    'n_train': int(train.sum()), 'n_test': int(test.sum()), 'MMD_tertile_cuts_train': MMD_CUTS,
    'n_rules_apriori': len(apriori_rules),
    'n_rules_final': len(rules), 'cart_params': gs.best_params_, 'cart_cv_auc': round(gs.best_score_, 4),
    'SL_count_reduction_%': round(100 * (base['SL'] - prop['SL']) / max(base['SL'], 1), 2),
    'SL_rate_change_pp': round(prop['SL_rate_%'] - base['SL_rate_%'], 2),
    'net_pips_change_%': round(100 * (prop['net_pips'] - base['net_pips']) / abs(base['net_pips']), 2) if base['net_pips'] else None,
    'CI95_SL_reduction_%': ci(boot_sl), 'CI95_net_pips_change_%': ci(boot_np),
    'p_vs_random_SL': p_rand_SL, 'p_vs_random_net_pips': p_rand_pips, 'wilcoxon_daily': wil,
}
# per pair x timeframe
grid = []
for (pr, tf), g in te.groupby(['pair', 'timeframe']):
    m = rej[g.index]
    grid.append({'pair': pr, 'timeframe': tf, 'trades': len(g), 'SL_before': int(g['y'].sum()),
                 'SL_after': int(g['y'][~m].sum()), 'pips_before': round(g['net_pips'].sum(), 1),
                 'pips_after': round(g['net_pips'][~m].sum(), 1)})

json.dump({'summary': summary, 'strategies': res, 'per_pair_timeframe': grid}, open('results.json', 'w'), indent=2, default=str)
with open('results.md', 'w') as f:
    f.write('# Out-of-sample results (test from %s)\n\n' % a.test_start)
    f.write(pd.DataFrame(res).T.to_markdown() + '\n\n## Per pair x timeframe\n\n' + pd.DataFrame(grid).to_markdown(index=False))
    f.write('\n\n## Summary\n\n```\n' + json.dumps(summary, indent=2, default=str) + '\n```\n')
    f.write('\n## Final rule base\n\n' + pd.DataFrame(rows).to_markdown(index=False) + '\n')
print(open('results.md').read())
