"""
Step 1 + Step 2: competing safeguards and threshold sensitivity on the positive-control design.
Methods:
  XAI   : Apriori (per partition, conf >= m*base, >=P partitions) + CART validation (leaf loss > base+g) + Jaccard merge
          default m=1.10, g=0.10, P=2
  APR   : Apriori-only (m=1.10, P=2, no CART)
  FBH   : class-association rules mined on full training (supp>=0.05, conf>base), one-sided Fisher exact test,
          Benjamini-Hochberg FDR q=0.05
  BRL   : Bayesian Rule List (imodels; maxcardinality 2, minsupport 0.05); risk rules = list entries with
          posterior loss prob >= base+0.10
Sensitivity: XAI over m in {1.05,1.10,1.20}, g in {0.05,0.10,0.15}, P in {1,2,3}.
"""
import os
import itertools, json, warnings, re
import numpy as np, pandas as pd
from scipy.stats import fisher_exact
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from mlxtend.frequent_patterns import apriori
from joblib import Parallel, delayed
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
F = ['PP', 'SRD', 'VR', 'PC', 'TL', 'CSC', 'UDF', 'MMD']
GRID = list(itertools.product([1.05, 1.10, 1.20], [0.05, 0.10, 0.15], [1, 2, 3]))

def load(f):
    d = pd.read_csv(S + f, parse_dates=['open_time'])
    tr = d.open_time < '2025'
    q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
    d['y'] = (d.outcome == 'SL').astype(int)
    I = pd.get_dummies(d[F].astype(str), prefix_sep='=').astype(bool)
    return d, I, tr.values

def covers(X, ante):
    m = np.ones(len(X), bool)
    for it in ante: m &= X[it].values
    return m

def jmerge(rules):
    rules = {r: set(p) for r, p in rules.items()}; ch = True
    while ch:
        ch = False
        for r1, r2 in itertools.combinations(list(rules), 2):
            if r1 in rules and r2 in rules and len(r1 & r2) / len(r1 | r2) >= 0.8:
                g = r1 & r2; ps = rules.pop(r1) | rules.pop(r2); rules[g] = rules.get(g, set()) | ps; ch = True; break
    return list(rules)

def artifacts(Xtr, ytr, strata, seed=42):
    base = ytr.mean()
    part_conf = {}   # rule -> {partition: conf}
    for k, (_, idx) in enumerate(StratifiedKFold(8, shuffle=True, random_state=seed).split(Xtr, strata), 1):
        T = Xtr.iloc[idx].copy(); T['C'] = ytr[idx].astype(bool)
        fi = apriori(T, min_support=0.05, use_colnames=True)
        sup = {frozenset(s): v for s, v in zip(fi['itemsets'], fi['support'])}
        for s, v in sup.items():
            if 'C' in s and len(s) > 1:
                a = s - {'C'}; c = v / sup[a]
                if c >= 1.05 * base: part_conf.setdefault(frozenset(a), {})[k] = c
    gs = GridSearchCV(DecisionTreeClassifier(random_state=seed), {'max_depth': [3, 4, 5, 6, 8], 'min_samples_leaf': [20, 40, 80]},
                      cv=10, scoring='roc_auc').fit(Xtr.values, ytr)
    leaf = gs.best_estimator_.apply(Xtr.values)
    pur = pd.Series(ytr).groupby(leaf).mean()
    cov = {r: covers(Xtr, r) for r in part_conf}
    return dict(base=base, part_conf=part_conf, leaf=leaf, pur=pur, cov=cov)

def xai_rules(A, m, g, P, use_cart=True):
    base = A['base']; risky = set(A['pur'][A['pur'] > base + g].index); inr = np.isin(A['leaf'], list(risky))
    cand = {}
    for r, pc in A['part_conf'].items():
        parts = {k for k, c in pc.items() if c >= max(0.60, m * base) or (m * base >= 0.60 and c >= m * base)}
        parts = {k for k, c in pc.items() if c >= m * base}
        if len(parts) >= P:
            if use_cart:
                cv = A['cov'][r]
                if not (cv.sum() and inr[cv].mean() >= 0.5): continue
            cand[r] = parts
    return jmerge(cand)

def fbh_rules(Xtr, ytr, q=0.05):
    base = ytr.mean(); T = Xtr.copy(); T['C'] = ytr.astype(bool)
    fi = apriori(T, min_support=0.05, use_colnames=True)
    sup = {frozenset(s): v for s, v in zip(fi['itemsets'], fi['support'])}
    rows = []
    n = len(ytr); L = ytr.sum()
    for s, v in sup.items():
        if 'C' in s and len(s) > 1:
            a = s - {'C'}; m = covers(Xtr, a); a1 = int(ytr[m].sum()); n1 = int(m.sum())
            if n1 == 0 or a1 / n1 <= base: continue
            p = fisher_exact([[a1, n1 - a1], [L - a1, (n - n1) - (L - a1)]], alternative='greater')[1]
            rows.append((a, p))
    if not rows: return []
    rows.sort(key=lambda t: t[1]); m_ = len(rows); keep = []
    kmax = 0
    for i, (a, p) in enumerate(rows, 1):
        if p <= q * i / m_: kmax = i
    return [a for a, p in rows[:kmax]]

def brl_rules(Xtr, ytr, seed=0):
    from imodels import BayesianRuleListClassifier
    base = ytr.mean(); cols = list(Xtr.columns)
    m = BayesianRuleListClassifier(listlengthprior=3, maxcardinality=2, minsupport=0.05, max_iter=2000, n_chains=2,
                                   random_state=seed, verbose=False)
    m.fit(Xtr.values.astype(int), ytr, feature_names=cols)
    out = []
    for i, its in enumerate(m.final_itemsets):
        if its == 'null' or its == ('null',) or i >= len(m.theta) - 1: continue
        items = [re.sub(r'\s*>\s*0\.5$', '', str(x)).strip() for x in (its if isinstance(its, (list, tuple)) else [its])]
        items = [cols[int(x[2:])] if re.fullmatch(r'X_\d+', x) else x for x in items]
        items = [x for x in items if x in cols]
        if items and m.theta[i] >= base + 0.10: out.append(frozenset(items))
    return out

def evaluate(rules, conj, I, te, y):
    J = lambda r: len(set(r) & set(conj)) / len(set(r) | set(conj)) if conj else 0
    hit = any(J(r) >= 0.5 for r in rules) if conj else False
    false = sum(J(r) < 0.5 for r in rules) if conj else len(rules)
    rej = np.zeros(te.sum(), bool); Xte = I[te]
    for r in rules: rej |= covers(Xte, r)
    yte = y[te]
    return dict(n_rules=len(rules), detected=hit, false_rules=false, rejected=int(rej.sum()),
                loss_all=float(yte.mean()), loss_kept=float(yte[~rej].mean()) if (~rej).sum() else np.nan)

def run(name, f, conj, delta, seed, mode):
    d, I, tr = load(f); rng = np.random.default_rng(seed); y = d.y.values.copy()
    if mode == 'pc' and conj:
        inC = covers(I, conj); pC = y[inC & tr].mean(); q = delta / (1 - pC) if delta > 0 else 0
        y[inC & (y == 0) & (rng.random(len(y)) < q)] = 1
    if mode == 'null':
        y[tr] = rng.permutation(y[tr])
    Xtr = I[tr].reset_index(drop=True); ytr = y[tr]; strata = (d.pair + d.timeframe)[tr].values
    A = artifacts(Xtr, ytr, strata); te = ~tr
    out = []
    base = dict(strategy=name, mode=mode, conj=' & '.join(conj) if conj else '', delta=delta, seed=seed)
    out.append({**base, 'method': 'XAI', **evaluate(xai_rules(A, 1.10, 0.10, 2), conj, I, te, y)})
    out.append({**base, 'method': 'APR', **evaluate(xai_rules(A, 1.10, 0.10, 2, use_cart=False), conj, I, te, y)})
    out.append({**base, 'method': 'FBH', **evaluate(fbh_rules(Xtr, ytr), conj, I, te, y)})
    try:
        out.append({**base, 'method': 'BRL', **evaluate(brl_rules(Xtr, ytr, seed), conj, I, te, y)})
    except Exception as e:
        out.append({**base, 'method': 'BRL', 'error': str(e)[:100]})
    for m, g, P in GRID:
        out.append({**base, 'method': f'XAI_m{m}_g{g}_P{P}', **evaluate(xai_rules(A, m, g, P), conj, I, te, y)})
    return out

if __name__ == '__main__':
    jobs = []
    for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
        d, I, tr = load(f); sup = {}
        for a, b in itertools.combinations(list(I.columns), 2):
            if a.split('=')[0] == b.split('=')[0]: continue
            s = covers(I[tr], (a, b)).mean()
            if 0.05 <= s <= 0.12: sup[(a, b)] = s
        keys = sorted(sup); rng = np.random.default_rng(2026)
        pick = [keys[i] for i in rng.choice(len(keys), 10, replace=False)]
        for c in pick:
            for delta in [0.0, 0.05, 0.10, 0.15, 0.20]:
                jobs.append((name, f, c, delta, 100 + len(jobs), 'pc'))
        for s_ in range(10): jobs.append((name, f, (), 0.0, 500 + s_, 'null'))
        jobs.append((name, f, (), 0.0, 42, 'real'))
    res = Parallel(n_jobs=2, verbose=5)(delayed(run)(*j) for j in jobs)
    R = pd.DataFrame([r for rr in res for r in rr])
    R.to_csv(S + 'results/robustness_runs.csv', index=False)
    print('done', len(R))
