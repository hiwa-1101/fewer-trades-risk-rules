import os
import pandas as pd, numpy as np, json, itertools, warnings; warnings.filterwarnings('ignore')
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import roc_auc_score
from mlxtend.frequent_patterns import apriori
B=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
F=['PP','SRD','VR','PC','TL','CSC','UDF','MMD']; out={}
def prep(f):
    d=pd.read_csv(B+f,parse_dates=['open_time','exit_time'])
    tr=d.open_time<'2025'; q1,q2=d.loc[tr,'mmd_raw'].quantile([1/3,2/3])
    d['MMD']=np.where(d.mmd_raw<q1,'Low',np.where(d.mmd_raw>q2,'High','Middle'))
    d['y']=(d.outcome=='SL').astype(int); d['R']=d.net_pips/d.sl_pips; d['Rg']=d.gross_pips/d.sl_pips; return d
rng=np.random.default_rng(7)
for name,f in [('reversal','mw_all.csv'),('trend','tf_all.csv')]:
    d=prep(f); tr=(d.open_time<'2025').values; te=~tr; o={}
    o['n']=len(d); o['n_train']=int(tr.sum()); o['n_test']=int(te.sum()); o['loss_rate_train']=round(d.y[tr].mean(),3); o['loss_rate_test']=round(d.y[te].mean(),3)
    X=pd.get_dummies(d[F].astype(str)).astype(int)
    for k,m in [('logit',LogisticRegression(max_iter=3000)),('cart',DecisionTreeClassifier(max_depth=4,min_samples_leaf=100,random_state=0)),('gbm',GradientBoostingClassifier(random_state=0,max_depth=3,n_estimators=200,learning_rate=0.05))]:
        m.fit(X[tr],d.y[tr]); p=m.predict_proba(X[te])[:,1]; a=roc_auc_score(d.y[te],p)
        bs=[]; yt=d.y[te].values
        for _ in range(500):
            i=rng.integers(0,len(p),len(p))
            if yt[i].min()!=yt[i].max(): bs.append(roc_auc_score(yt[i],p[i]))
        o['auc_'+k]=[round(a,3),round(np.percentile(bs,2.5),3),round(np.percentile(bs,97.5),3)]
    # in-sample vs out-of-sample: top-10 Apriori rules by training confidence (support>=0.02, len<=3)
    I=pd.get_dummies(d[F].astype(str),prefix_sep='=').astype(bool); T=I[tr].copy(); T['C']=d.y[tr].values.astype(bool)
    fi=apriori(T,min_support=0.02,use_colnames=True,max_len=4); sup={frozenset(s):v for s,v in zip(fi.itemsets,fi.support)}
    rules=[]
    for s,v in sup.items():
        if 'C' in s and len(s)>1:
            a_=s-{'C'}; rules.append((v/sup[a_],a_))
    rules.sort(key=lambda t:-t[0]); top=[]
    for conf,a_ in rules[:10]:
        m=np.ones(len(d),bool)
        for it in a_: m&=I[it].values
        top.append(dict(rule=' & '.join(sorted(a_)),train_conf=round(conf,3),n_test=int((m&te).sum()),test_loss=round(d.y[m&te].mean(),3)))
    o['top10']=top; o['top10_train_mean']=round(np.mean([t['train_conf'] for t in top]),3); o['top10_test_mean']=round(np.mean([t['test_loss'] for t in top]),3)
    out[name]=o
# data-snooping illustration on reversal: 60-config pre-trade filter grid
d=prep('mw_all.csv'); d['hour']=d.open_time.dt.hour; d['yr']=d.open_time.dt.year
grid=list(itertools.product([0,9,12,16,22],[99,1.0,0.5],['all','06-18'],['all','High']))
def mk(x,c):
    mn,ms,ss,vr=c; m=(x.sl_pips>=mn)&(x.spread_pips<=ms)
    if ss=='06-18': m&=x.hour.between(6,17)
    if vr=='High': m&=x.VR.eq('High')
    return m
c=[]
for g in grid:
    a=d[(d.yr==2023)&mk(d,g)]; b=d[(d.yr==2024)&mk(d,g)]
    if len(a)>=300 and len(b)>=300: c.append((min(a.R.mean(),b.R.mean()),g))
c.sort(reverse=True); g=c[0][1]; tr_=d[(d.yr<=2024)&mk(d,g)]; te_=d[(d.yr==2025)&mk(d,g)]
bs=[te_.R.values[rng.integers(0,len(te_),len(te_))].mean() for _ in range(5000)]
out['snoop']=dict(n_configs=len(grid),eligible=len(c),config=dict(min_sl_pips=g[0],max_spread=g[1],session=g[2],vr=g[3]),
   train=dict(n=len(tr_),R=round(tr_.R.mean(),3),PF=round(tr_.net_pips[tr_.net_pips>0].sum()/-tr_.net_pips[tr_.net_pips<0].sum(),2)),
   test=dict(n=len(te_),R=round(te_.R.mean(),3),lo=round(np.percentile(bs,2.5),3),hi=round(np.percentile(bs,97.5),3),PF=round(te_.net_pips[te_.net_pips>0].sum()/-te_.net_pips[te_.net_pips<0].sum(),2)))
# spreads and SL sizes per TF
cm=pd.read_csv(B+'combined_trades.csv',parse_dates=['open_time'])
out['spread_by_pair']=cm.groupby('pair').spread_pips.median().round(2).to_dict()
out['sl_pips_median']=cm.groupby(['strategy','timeframe']).sl_pips.median().round(1).unstack().to_dict()
out['cost_R']=cm.assign(c=cm.Rg-cm.R).groupby(['strategy','timeframe']).c.mean().round(3).unstack().to_dict()
json.dump(out,open(B+'results/final_numbers.json','w'),indent=1,default=str)
print(json.dumps(out,indent=1,default=str)[:6000])
