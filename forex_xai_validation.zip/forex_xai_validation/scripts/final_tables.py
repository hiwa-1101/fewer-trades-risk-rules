import os
import sys, numpy as np, pandas as pd, warnings, json; warnings.filterwarnings('ignore')
S=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0,S+'scripts'); sys.argv=['x']
import robustness as rb
from sklearn.linear_model import LogisticRegression
rng=np.random.default_rng(9); OUT={}
def prep(f,train_end,test_year):
    d=pd.read_csv(S+f,parse_dates=['open_time']); tr=(d.open_time<train_end).values; te=(d.open_time.dt.year==test_year).values
    q1,q2=d.loc[tr,'mmd_raw'].quantile([1/3,2/3]); d['MMD']=np.where(d.mmd_raw<q1,'Low',np.where(d.mmd_raw>q2,'High','Middle'))
    d['y']=(d.outcome=='SL').astype(int); d['R']=d.net_pips/d.sl_pips
    I=pd.get_dummies(d[rb.F].astype(str),prefix_sep='=').astype(bool); return d,I,tr,te
def effect(d,te,rej):
    t=d[te].reset_index(drop=True); day=t.open_time.dt.normalize().values; days,inv=np.unique(day,return_inverse=True)
    sa=np.bincount(inv,weights=t.R.values); na=np.bincount(inv); sk=np.bincount(inv,weights=t.R.values*(~rej)); nk=np.bincount(inv,weights=(~rej).astype(float))
    ci=None
    if rej.any() and (~rej).any():
        bs=[]
        for _ in range(4000):
            i=rng.integers(0,len(days),len(days))
            if nk[i].sum()>0: bs.append(sk[i].sum()/nk[i].sum()-sa[i].sum()/na[i].sum())
        ci=[round(np.percentile(bs,2.5),3),round(np.percentile(bs,97.5),3)]
    return dict(rejected_pct=round(100*rej.mean(),1),loss_kept=round(t.y[~rej].mean(),3) if (~rej).any() else None,base=round(t.y.mean(),3),
                R_kept=round(t.R[~rej].mean(),3) if (~rej).any() else None,R_all=round(t.R.mean(),3),dR_ci=ci)
for name,f in [('Reversal','mw_all.csv'),('Trend','tf_all.csv')]:
    for fold,(end,yr) in {'2023-24->2025':('2025-01-01',2025),'2023->2024':('2024-01-01',2024)}.items():
        d,I,tr,te=prep(f,end,yr); Xtr=I[tr].reset_index(drop=True); ytr=d.y.values[tr]
        A=rb.artifacts(Xtr,ytr,(d.pair+d.timeframe)[tr].values); Xte=I[te]
        meth={'Apriori only':rb.xai_rules(A,1.10,0.10,2,use_cart=False),'Apriori-CART':rb.xai_rules(A,1.10,0.10,2),
              'Fisher-BH':rb.fbh_rules(Xtr,ytr),'BRL':rb.brl_rules(Xtr,ytr,0)}
        for mname,rules in meth.items():
            rej=np.zeros(te.sum(),bool)
            for r in rules: rej|=rb.covers(Xte,r).astype(bool)
            OUT.setdefault(name,{}).setdefault(fold,{})[mname]=dict(n_rules=len(rules),rules=[' & '.join(sorted(r)) for r in rules][:6],**effect(d,te,rej))
        if fold=='2023-24->2025':
            X=pd.get_dummies(d[rb.F].astype(str)).astype(int); yr23=(d.open_time.dt.year==2023).values; yr24=(d.open_time.dt.year==2024).values
            m1=LogisticRegression(max_iter=3000).fit(X[yr23],d.y[yr23]); p24=m1.predict_proba(X[yr24])[:,1]; R24=d.R[yr24].values
            best=(0.0,R24.mean())
            for s in [0.1,0.2,0.3,0.4,0.5]:
                acc=p24<np.quantile(p24,1-s)
                if R24[acc].mean()>best[1]: best=(s,R24[acc].mean())
            m2=LogisticRegression(max_iter=3000).fit(X[tr],d.y[tr]); thr=np.quantile(m2.predict_proba(X[tr])[:,1],1-best[0]) if best[0]>0 else np.inf
            rej=~(m2.predict_proba(X[te])[:,1]<thr)
            OUT[name][fold]['Cost-aware logistic']=dict(n_rules=None,share=best[0],**effect(d,te,rej))
json.dump(OUT,open(S+'results/final_tables.json','w'),indent=1,default=str)
for n in OUT:
    for fo in OUT[n]:
        print(n,fo)
        for m,v in OUT[n][fo].items(): print('   ',m,{k:v[k] for k in v if k!='rules'}, v.get('rules'))
