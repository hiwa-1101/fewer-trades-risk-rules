"""Cost-aware logistic filter retrained each 2025 quarter (expanding window); rejection share fixed on 2023->2024
validation (results/r3.json 'logit' -> 'chosen'). Pooled delta R over 2025 with day-block bootstrap. Output: results/logit_quarterly.json"""
import os, sys, json, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0, S + 'scripts'); sys.argv = ['x']
import robustness as rb
R3 = json.load(open(S + 'results/r3.json'))
rng = np.random.default_rng(21); OUT = {}
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    share = R3['logit'][name]['chosen']; parts = []; perq = {}
    for q in pd.period_range('2025Q1', '2025Q4', freq='Q'):
        d = pd.read_csv(S + f, parse_dates=['open_time']); tr = (d.open_time < q.start_time).values
        te = ((d.open_time >= q.start_time) & (d.open_time < (q + 1).start_time)).values
        q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
        d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
        d['y'] = (d.outcome == 'SL').astype(int); d['R'] = d.net_pips / d.sl_pips
        X = pd.get_dummies(d[rb.F].astype(str)).astype(int)
        m = LogisticRegression(max_iter=3000).fit(X[tr], d.y[tr])
        thr = np.quantile(m.predict_proba(X[tr])[:, 1], 1 - share); acc = m.predict_proba(X[te])[:, 1] < thr
        t = d[te]; perq[str(q)] = round(t.R[acc].mean() - t.R.mean(), 3)
        parts.append(pd.DataFrame(dict(day=t.open_time.dt.normalize().values, R=t.R.values, acc=acc)))
    P = pd.concat(parts, ignore_index=True)
    days, inv = np.unique(P.day.values, return_inverse=True)
    sa = np.bincount(inv, P.R.values); na = np.bincount(inv); sk = np.bincount(inv, P.R.values * P.acc.values); nk = np.bincount(inv, P.acc.values.astype(float))
    bs = []
    for _ in range(3000):
        i = rng.integers(0, len(days), len(days)); bs.append(sk[i].sum() / nk[i].sum() - sa[i].sum() / na[i].sum())
    OUT[name] = dict(share=share, R_all=round(P.R.mean(), 3), R_kept=round(P.R[P.acc].mean(), 3),
                     dR=round(P.R[P.acc].mean() - P.R.mean(), 3), ci=[round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)],
                     per_quarter=perq)
json.dump(OUT, open(S + 'results/logit_quarterly.json', 'w'), indent=1); print(json.dumps(OUT, indent=1))
