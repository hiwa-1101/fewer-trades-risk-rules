"""R1/R2: enlarged positive control (50 conjunctions x 5 deltas) and 100-run permutation null.
Methods: XAI (Apriori-CART default), APR (Apriori only), FBH (Fisher-BH), FBHC (Fisher-BH -> CART validation -> Jaccard merge).
BRL study (mode brl): list length 3/6, risk margin 0.05/0.10 on 20 conjunctions x {10,15,20} and 30 nulls.
"""
import os
import itertools, sys, warnings, re
import numpy as np, pandas as pd
from joblib import Parallel, delayed
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0, S + 'scripts'); sys.argv = sys.argv[:2] if len(sys.argv) > 1 else ['x']
import robustness as rb

def cart_validate(A, Xtr, rules, g=0.10):
    base = A['base']; risky = set(A['pur'][A['pur'] > base + g].index); inr = np.isin(A['leaf'], list(risky))
    keep = {}
    for r in rules:
        cv = rb.covers(Xtr, r)
        if cv.sum() and inr[cv].mean() >= 0.5: keep[frozenset(r)] = {0}
    return rb.jmerge(keep)

def brl_fit(Xtr, ytr, length, seed):
    from imodels import BayesianRuleListClassifier
    m = BayesianRuleListClassifier(listlengthprior=length, maxcardinality=2, minsupport=0.05, max_iter=2000, n_chains=2,
                                   random_state=seed, verbose=False)
    m.fit(Xtr.values.astype(int), ytr, feature_names=list(Xtr.columns))
    out = []
    for i, its in enumerate(m.final_itemsets):
        if i >= len(m.theta) - 1: continue
        items = [re.sub(r'\s*>\s*0\.5$', '', str(x)).strip() for x in (its if isinstance(its, (list, tuple)) else [its])]
        cols = list(Xtr.columns)
        items = [cols[int(x[2:])] if re.fullmatch(r'X_\d+', x) else x for x in items]
        items = [x for x in items if x in cols]
        if items: out.append((frozenset(items), float(m.theta[i])))
    return out

def prepare(f, conj, delta, seed, mode):
    d, I, tr = rb.load(f); rng = np.random.default_rng(seed); y = d.y.values.copy()
    if conj and delta > 0:
        inC = rb.covers(I, conj); pC = y[inC & tr].mean(); q = delta / (1 - pC)
        y[inC & (y == 0) & (rng.random(len(y)) < q)] = 1
    if mode == 'null':
        y[tr] = rng.permutation(y[tr])
    return d, I, tr, y

def run_main(name, f, conj, delta, seed, mode):
    d, I, tr, y = prepare(f, conj, delta, seed, mode)
    Xtr = I[tr].reset_index(drop=True); ytr = y[tr]
    A = rb.artifacts(Xtr, ytr, (d.pair + d.timeframe)[tr].values); te = ~tr
    fbh = rb.fbh_rules(Xtr, ytr)
    meth = {'XAI': rb.xai_rules(A, 1.10, 0.10, 2), 'APR': rb.xai_rules(A, 1.10, 0.10, 2, use_cart=False),
            'FBH': fbh, 'FBHC': cart_validate(A, Xtr, fbh)}
    base = dict(strategy=name, mode=mode, conj=' & '.join(conj) if conj else '', delta=delta, seed=seed)
    return [{**base, 'method': m, **rb.evaluate(r, conj, I, te, y)} for m, r in meth.items()]

def run_brl(name, f, conj, delta, seed, mode):
    d, I, tr, y = prepare(f, conj, delta, seed, mode)
    Xtr = I[tr].reset_index(drop=True); ytr = y[tr]; base_rate = ytr.mean(); te = ~tr
    out = []
    for L in (3, 6):
        try:
            fitted = brl_fit(Xtr, ytr, L, seed)
        except Exception as e:
            out.append(dict(strategy=name, mode=mode, delta=delta, seed=seed, method=f'BRL_L{L}', error=str(e)[:80])); continue
        for g in (0.05, 0.10):
            rules = [r for r, th in fitted if th >= base_rate + g]
            out.append(dict(strategy=name, mode=mode, conj=' & '.join(conj) if conj else '', delta=delta, seed=seed,
                            method=f'BRL_L{L}_g{g}', **rb.evaluate(rules, conj, I, te, y)))
    return out

def conj_pool(f, n, seed=2026):
    d, I, tr = rb.load(f); sup = {}
    for a, b in itertools.combinations(list(I.columns), 2):
        if a.split('=')[0] == b.split('=')[0]: continue
        s = rb.covers(I[tr], (a, b)).mean()
        if 0.05 <= s <= 0.12: sup[(a, b)] = s
    keys = sorted(sup); rng = np.random.default_rng(seed)
    return [keys[i] for i in rng.choice(len(keys), min(n, len(keys)), replace=False)]

if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'main'
    jobs = []
    for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
        if which == 'main':
            for c in conj_pool(f, 50):
                for delta in [0.0, 0.05, 0.10, 0.15, 0.20]:
                    jobs.append((name, f, c, delta, 1000 + len(jobs), 'pc'))
            for s_ in range(100): jobs.append((name, f, (), 0.0, 5000 + s_, 'null'))
        else:
            for c in conj_pool(f, 20, seed=7):
                for delta in [0.10, 0.15, 0.20]:
                    jobs.append((name, f, c, delta, 3000 + len(jobs), 'pc'))
            for s_ in range(30): jobs.append((name, f, (), 0.0, 7000 + s_, 'null'))
            jobs.append((name, f, (), 0.0, 42, 'real'))
    fn = run_main if which == 'main' else run_brl
    res = Parallel(n_jobs=2, verbose=5)(delayed(fn)(*j) for j in jobs)
    R = pd.DataFrame([r for rr in res for r in rr])
    R.to_csv(S + f'results/robustness2_{which}.csv', index=False)
    print('done', which, len(R))
