import os
import pandas as pd, numpy as np, glob
from scipy.stats import mannwhitneyu
B=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
def load(pat,name):
    d=pd.concat([pd.read_csv(f) for f in glob.glob(B+pat)],ignore_index=True)
    d['pair']=d.pair.str[:6]; d['open_time']=pd.to_datetime(d.open_time); d['exit_time']=pd.to_datetime(d.exit_time)
    d['R']=d.net_pips/d.sl_pips; d['Rg']=d.gross_pips/d.sl_pips; d['strategy']=name
    d['period']=np.where(d.open_time.dt.year<=2024,'2023-24','2025'); return d
mw=load('real/MW_trades_*.csv','Reversal'); tf=load('tf/TF_trades_*.csv','Trend')
print('R mismatch check TF (|R_file - net/sl|>0.05):',(abs(load('tf/TF_trades_*.csv','x').R-pd.concat([pd.read_csv(f) for f in glob.glob(B+'tf/TF_trades_*.csv')]).R.values)>0.05).sum())
d=pd.concat([mw,tf],ignore_index=True)
rng=np.random.default_rng(0)
def ci(x,B=5000):
    x=x.values; bs=[x[rng.integers(0,len(x),len(x))].mean() for _ in range(B)]; return np.percentile(bs,[2.5,97.5])
def maxdd(x):
    c=x.sort_values('exit_time').R.cumsum(); return (c.cummax()-c).max()
rows=[]
for (s,tfm,p),g in d.groupby(['strategy','timeframe','period']):
    lo,hi=ci(g.R,2000)
    rows.append(dict(strategy=s,tf=tfm,period=p,n=len(g),win=round((g.R>0).mean(),3),R_gross=round(g.Rg.mean(),3),R_net=round(g.R.mean(),3),
        lo=round(lo,3),hi=round(hi,3),PF=round(g.net_pips[g.net_pips>0].sum()/-g.net_pips[g.net_pips<0].sum(),2),
        sumR=round(g.R.sum(),1),maxDD_R=round(maxdd(g),1)))
T=pd.DataFrame(rows); T['tf']=pd.Categorical(T.tf,['M5','M15','H1','H4']); T=T.sort_values(['period','tf','strategy'])
print(T.to_string(index=False))
print('\nPooled across timeframes:')
for (s,p),g in d.groupby(['strategy','period']):
    lo,hi=ci(g.R); print(f'{s:18s} {p}: n={len(g)} R_net={g.R.mean():.3f} [{lo:.3f},{hi:.3f}] R_gross={g.Rg.mean():.3f} PF={g.net_pips[g.net_pips>0].sum()/-g.net_pips[g.net_pips<0].sum():.2f}')
print('\nMann-Whitney (2025, Trend vs Reversal R):')
for t in ['M5','M15','H1','H4']:
    a=tf[(tf.timeframe==t)&(tf.period=='2025')].R; b=mw[(mw.timeframe==t)&(mw.period=='2025')].R
    u=mannwhitneyu(a,b,alternative='two-sided'); print(t,'U=%.0f p=%.4g  meanR TF=%.3f MW=%.3f'%(u.statistic,u.pvalue,a.mean(),b.mean()))
print('\nTrend 2025 by pair x tf (R_net mean, n):')
print(tf[tf.period=='2025'].groupby(['pair','timeframe']).R.agg(['size','mean','sum']).round(3).to_string())
print('\nTrend: share of trades with R < -1.5 (gap through stop):',tf.groupby('timeframe').R.apply(lambda r:(r<-1.5).mean()).round(4).to_dict())
d.to_csv(B+'combined_trades.csv',index=False); T.to_csv(B+'comparison_table.csv',index=False)
