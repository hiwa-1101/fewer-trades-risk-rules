"""R3: quarterly expanding walk-forward, block-bootstrap family comparison, extended logistic grid."""
import sys, json, warnings
import os
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0, S + 'scripts'); sys.argv = ['x']
import robustness as rb, robustness2 as r2
rng = np.random.default_rng(21); OUT = {}

def holm(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for k, i in enumerate(o):
        run = max(run, min(1, (m - k) * p[i])); adj[i] = run
    return adj

def load_split(f, train_end, test_start, test_end):
    d = pd.read_csv(S + f, parse_dates=['open_time'])
    tr = (d.open_time < train_end).values; te = ((d.open_time >= test_start) & (d.open_time < test_end)).values
    q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
    d['y'] = (d.outcome == 'SL').astype(int); d['R'] = d.net_pips / d.sl_pips
    I = pd.get_dummies(d[rb.F].astype(str), prefix_sep='=').astype(bool)
    return d, I, tr, te

def block_ci_diff(day, R, acc, B=3000):
    days, inv = np.unique(day, return_inverse=True)
    sa = np.bincount(inv, weights=R); na = np.bincount(inv); sk = np.bincount(inv, weights=R * acc); nk = np.bincount(inv, weights=acc.astype(float))
    bs = []
    for _ in range(B):
        i = rng.integers(0, len(days), len(days))
        if nk[i].sum() > 0: bs.append(sk[i].sum() / nk[i].sum() - sa[i].sum() / na[i].sum())
    return [round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)]

# ---- (a) quarterly expanding walk-forward
quarters = pd.period_range('2024Q1', '2025Q4', freq='Q')
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    folds = []; pooled = {m: [] for m in ['XAI', 'FBH', 'FBHC', 'BRL']}
    for q in quarters:
        start, end = q.start_time, (q + 1).start_time
        d, I, tr, te = load_split(f, start, start, end)
        Xtr = I[tr].reset_index(drop=True); ytr = d.y.values[tr]
        A = rb.artifacts(Xtr, ytr, (d.pair + d.timeframe)[tr].values)
        fbh = rb.fbh_rules(Xtr, ytr)
        try:
            brl = [r for r, th in r2.brl_fit(Xtr, ytr, 3, 0) if th >= ytr.mean() + 0.10]
        except Exception:
            brl = []
        meth = {'XAI': rb.xai_rules(A, 1.10, 0.10, 2), 'FBH': fbh, 'FBHC': r2.cart_validate(A, Xtr, fbh), 'BRL': brl}
        t = d[te].reset_index(drop=True); Xte = I[te]; day = t.open_time.dt.normalize().values
        row = dict(quarter=str(q), n_train=int(tr.sum()), n_test=int(te.sum()))
        for m, rules in meth.items():
            rej = np.zeros(len(t), bool)
            for r in rules: rej |= rb.covers(Xte, r).astype(bool)
            dR = (t.R[~rej].mean() - t.R.mean()) if (~rej).any() else np.nan
            row[m] = dict(n_rules=len(rules), rules=sorted(' & '.join(sorted(r)) for r in rules), rej_pct=round(100 * rej.mean(), 1),
                          dR=round(dR, 3) if rules else 0.0)
            pooled[m].append(pd.DataFrame(dict(day=day, R=t.R.values, acc=~rej)))
        folds.append(row)
    summ = {}
    for m in pooled:
        P = pd.concat(pooled[m], ignore_index=True)
        rule_sets = [set(fo[m]['rules']) for fo in folds]
        jac = [len(a & b) / len(a | b) for a, b in zip(rule_sets[:-1], rule_sets[1:]) if (a | b)]
        summ[m] = dict(folds_with_rules=sum(len(s) > 0 for s in rule_sets),
                       mean_rules=round(np.mean([len(s) for s in rule_sets]), 2),
                       consecutive_jaccard=round(float(np.mean(jac)), 3) if jac else None,
                       pooled_rej_pct=round(100 * (1 - P.acc.mean()), 1),
                       pooled_dR=round(P.R[P.acc].mean() - P.R.mean(), 3) if (~P.acc).any() else 0.0,
                       pooled_dR_ci=block_ci_diff(P.day.values, P.R.values, P.acc.values) if (~P.acc).any() else None)
    OUT.setdefault('walk_forward', {})[name] = dict(folds=folds, summary=summ)

# ---- (b) block-bootstrap difference in mean R between families (8 comparisons)
cm = pd.read_csv(S + 'combined_trades.csv', parse_dates=['open_time'])
comp = []
for tf in ['M5', 'M15', 'H1', 'H4']:
    for per in ['2023-24', '2025']:
        a = cm[(cm.strategy == 'Trend') & (cm.timeframe == tf) & (cm.period == per)]
        b = cm[(cm.strategy == 'Reversal') & (cm.timeframe == tf) & (cm.period == per)]
        days = np.unique(np.concatenate([a.open_time.dt.normalize().values, b.open_time.dt.normalize().values]))
        ia = np.searchsorted(days, a.open_time.dt.normalize().values); ib = np.searchsorted(days, b.open_time.dt.normalize().values)
        sa = np.bincount(ia, weights=a.R.values, minlength=len(days)); na = np.bincount(ia, minlength=len(days))
        sb = np.bincount(ib, weights=b.R.values, minlength=len(days)); nb = np.bincount(ib, minlength=len(days))
        bs = []
        for _ in range(4000):
            i = rng.integers(0, len(days), len(days))
            if na[i].sum() and nb[i].sum(): bs.append(sa[i].sum() / na[i].sum() - sb[i].sum() / nb[i].sum())
        bs = np.array(bs); diff = a.R.mean() - b.R.mean()
        p = min(1, 2 * min((bs <= 0).mean(), (bs >= 0).mean()))
        comp.append(dict(tf=tf, period=per, diff=round(diff, 3), ci=[round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)], p=p))
C = pd.DataFrame(comp); C['p_holm'] = holm(C.p.values).round(4)
OUT['family_diff'] = C.to_dict('records')

# ---- (c) logistic reference filter with share grid 0.1..0.7
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    d, I, tr, te = load_split(f, '2025-01-01', '2025-01-01', '2026-01-01')
    X = pd.get_dummies(d[rb.F].astype(str)).astype(int)
    y23 = (d.open_time.dt.year == 2023).values; y24 = (d.open_time.dt.year == 2024).values
    m1 = LogisticRegression(max_iter=3000).fit(X[y23], d.y[y23]); p24 = m1.predict_proba(X[y24])[:, 1]; R24 = d.R[y24].values
    grid = {}
    for s in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]:
        acc = p24 < np.quantile(p24, 1 - s); grid[s] = round(R24[acc].mean(), 4)
    share = max(grid, key=grid.get)
    m2 = LogisticRegression(max_iter=3000).fit(X[tr], d.y[tr]); thr = np.quantile(m2.predict_proba(X[tr])[:, 1], 1 - share)
    acc = m2.predict_proba(X[te])[:, 1] < thr; t = d[te]
    OUT.setdefault('logit', {})[name] = dict(val_grid=grid, val_unfiltered=round(R24.mean(), 4), chosen=share,
        rej_pct=round(100 * (1 - acc.mean()), 1), R_all=round(t.R.mean(), 3), R_kept=round(t.R[acc].mean(), 3),
        loss_kept=round(t.y[acc].mean(), 3), dR_ci=block_ci_diff(t.open_time.dt.normalize().values, t.R.values, acc))
json.dump(OUT, open(S + 'results/r3.json', 'w'), indent=1, default=str)
print(json.dumps({k: (v if k != 'walk_forward' else {n: v[n]['summary'] for n in v}) for k, v in OUT.items()}, indent=1, default=str))
for n in OUT['walk_forward']:
    for fo in OUT['walk_forward'][n]['folds']:
        print(n, fo['quarter'], {m: (fo[m]['n_rules'], fo[m]['dR']) for m in ['XAI', 'FBH', 'FBHC', 'BRL']})
