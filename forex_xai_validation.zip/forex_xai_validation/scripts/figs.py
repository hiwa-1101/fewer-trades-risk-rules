import os
import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
B=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':7.5,'axes.linewidth':0.6,'savefig.dpi':300})
t=pd.read_csv(B+'comparison_table.csv'); J=json.load(open(B+'results/final_numbers.json'))
_st=json.load(open(B+'results/step3_stats.json'))
for c in _st['cells']:
    lo,hi=(c['ci_block'] if isinstance(c['ci_block'],list) else eval(c['ci_block']))
    m=(t.strategy==c['strategy'])&(t.tf==c['tf'])&(t.period==c['period']); t.loc[m,'lo']=lo; t.loc[m,'hi']=hi
TF=['M5','M15','H1','H4']; COL={'Reversal':'#7a7a7a','Trend':'#1f4e79'}
# ---- Fig 1: workflow (2 rows x 3 boxes)
fig,ax=plt.subplots(figsize=(3.45,1.9)); ax.axis('off'); ax.set_xlim(0,12); ax.set_ylim(0,6.2)
def box(x,y,w,h,txt,fc='#eef3f8'):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.05,rounding_size=0.15',fc=fc,ec='#1f4e79',lw=0.6))
    ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=5.4,linespacing=1.15)
def arr(x1,y1,x2,y2): ax.annotate('',(x2,y2),(x1,y1),arrowprops=dict(arrowstyle='->',lw=0.6,color='#333'))
W,H=3.4,2.3
box(0.1,3.6,W,H,'MT5 real ticks\nmajor pairs\nM5-H4, 2021 and\n2023-2025')
box(4.3,3.6,W,H,'A: 2021 M/W\nexperts, 5 rules\nB: reversal and\ntrend families',fc='#f2f2f2')
box(8.5,3.6,W,H,'Trade log, net of\ncosts, with 8 pre-\ntrade descriptors')
box(8.5,0.2,W,H,'Risk rules:\nhand-written (A)\nor mined (B),\npast data only')
box(4.3,0.2,W,H,'Score: mean R of\naccepted trades vs.\nrandom blocking;\nheld-out, pre-reg.')
box(0.1,0.2,W,H,'Planted effects,\npermutation null,\nwalk-forward,\nSPA test')
arr(3.5,4.75,4.3,4.75); arr(7.7,4.75,8.5,4.75); arr(10.2,3.6,10.2,2.5); arr(8.5,1.35,7.7,1.35); arr(4.3,1.35,3.5,1.35)
fig.savefig(B+'results/fig1_workflow.png',bbox_inches='tight'); plt.close()
# ---- Fig 3: mean net R by TF with CI, two panels
fig,axs=plt.subplots(1,2,figsize=(3.45,1.75),sharey=True)
for ax,p in zip(axs,['2023-24','2025']):
    for k,(s,off) in enumerate([('Reversal',-0.18),('Trend',0.18)]):
        r=t[(t.strategy==s)&(t.period==p)].set_index('tf').loc[TF]
        x=np.arange(4)+off; ax.bar(x,r.R_net,0.34,color=COL[s],label=s if p=='2023-24' else None)
        ax.errorbar(x,r.R_net,yerr=[r.R_net-r.lo,r.hi-r.R_net],fmt='none',ecolor='k',elinewidth=0.6,capsize=1.5)
    ax.axhline(0,color='k',lw=0.6); ax.set_xticks(range(4)); ax.set_xticklabels(TF); ax.set_title(('Training ' if p=='2023-24' else 'Test ')+p,fontsize=7.5)
    ax.grid(axis='y',lw=0.3,alpha=0.5)
axs[0].set_ylabel('Mean net R per trade'); axs[0].legend(frameon=False,fontsize=6.5,loc='upper left')
fig.tight_layout(pad=0.3); fig.savefig(B+'results/fig3_R_by_tf.png'); plt.close()
# ---- Fig 4: in-sample vs out-of-sample
fig,axs=plt.subplots(1,2,figsize=(3.45,1.7),gridspec_kw={'width_ratios':[1.25,1]})
ax=axs[0]
for s,key in [('Reversal','reversal'),('Trend','trend')]:
    tt=J[key]['top10']; tr=[x['train_conf'] for x in tt]; te=[x['test_loss'] for x in tt]
    ax.scatter(tr,te,s=9,color=COL[s],label=s,zorder=3)
    ax.axhline(J[key]['loss_rate_test'],color=COL[s],lw=0.6,ls='--')
lims=[0.55,0.82]; ax.plot(lims,lims,color='k',lw=0.5,ls=':'); ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_xlabel('Loss rate, training (2023-24)'); ax.set_ylabel('Loss rate, test (2025)'); ax.set_title('(a) Top-10 rules per strategy',fontsize=7)
ax.legend(frameon=False,fontsize=6,loc='upper left')
ax=axs[1]; S=J['snoop']; vals=[S['train']['R'],S['test']['R']]
ax.bar([0,1],vals,0.55,color=['#9db7d5','#1f4e79']); ax.errorbar([1],[S['test']['R']],yerr=[[S['test']['R']-S['test']['lo']],[S['test']['hi']-S['test']['R']]],fmt='none',ecolor='k',elinewidth=0.6,capsize=2)
ax.axhline(0,color='k',lw=0.6); ax.set_xticks([0,1]); ax.set_xticklabels(['2023-24\n(selected)','2025\n(test)']); ax.set_ylabel('Mean net R'); ax.set_title('(b) Best of 60 filters',fontsize=7)
ax.text(0,vals[0]+0.012,f'{vals[0]:+.3f}',ha='center',fontsize=6.3); ax.text(1,vals[1]/2,f'{vals[1]:+.3f}',ha='center',va='center',color='white',fontsize=6.3)
ax.set_ylim(-0.27,0.1); fig.tight_layout(pad=0.3); fig.savefig(B+'results/fig4_insample_vs_oos.png'); plt.close()
print('ok')

# ---- Fig 4: sensitivity / safeguard comparison (grid: robustness_runs; safeguards: robustness2_main / brl)
SS=pd.read_csv(B+'results/sensitivity_summary.csv')
R2=pd.read_csv(B+'results/robustness2_main.csv',keep_default_na=False,na_values=[''])
BR=pd.read_csv(B+'results/robustness2_brl.csv',keep_default_na=False,na_values=[''])
best=json.load(open(B+'results/brl_summary.json'))['best_method']
fig,axs=plt.subplots(1,2,figsize=(3.45,1.8),sharey=True)
for ax,s_ in zip(axs,['Reversal','Trend']):
    g=SS[SS.strategy==s_]
    ax.scatter(g.null_rules,g.det15,s=10,color='#b0b0b0',label='Apriori-CART grid',zorder=2)
    for meth,mk,col,lab,src in [('XAI','*','#1f4e79','Apriori-CART',R2),('FBH','s','#c55a11','Fisher-BH',R2),('FBHC','D','#7030a0','FBH→CART',R2),
                                ('APR','x','k','Apriori only',R2),(best,'^','#548235','BRL (best)',BR)]:
        nu=src[(src['mode']=='null')&(src.method==meth)&(src.strategy==s_)].n_rules.mean()
        de=src[(src['mode']=='pc')&(src.method==meth)&(src.strategy==s_)&(src.delta.round(2)==0.15)].detected.mean()
        ax.scatter([nu],[de],s=26 if mk=='*' else 16,marker=mk,color=col,label=lab,zorder=4)
    ax.set_xscale('symlog',linthresh=1); ax.set_xlim(-0.15,80); ax.set_xticks([0,1,10,50]); ax.set_xticklabels(['0','1','10','50']); ax.minorticks_off()
    ax.set_ylim(-0.05,1.05); ax.set_title(s_,fontsize=7.5); ax.set_xlabel('False rules / null run'); ax.grid(lw=0.3,alpha=0.5)
axs[0].set_ylabel('Detection (Δ = 15 pp)')
h,l=axs[1].get_legend_handles_labels(); fig.legend(h,l,loc='lower center',ncol=3,fontsize=5.6,frameon=False,bbox_to_anchor=(0.5,-0.02))
fig.tight_layout(pad=0.3,rect=(0,0.16,1,1)); fig.savefig(B+'results/fig5_sensitivity.png'); plt.close()
print('fig5 ok')
