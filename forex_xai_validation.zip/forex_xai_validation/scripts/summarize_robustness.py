"""Summaries used by the paper and Fig. 3:
 results/r1_summary.json      (Table V rows for APR, XAI = Apriori-CART, FBH, FBHC; from robustness2_main.csv)
 results/brl_summary.json     (Table V BRL rows; best = most specific BRL setting; from robustness2_brl.csv)
 results/sensitivity_summary.csv (27-point Apriori-CART threshold grid; from robustness_runs.csv)"""
import json, sys, os
import numpy as np, pandas as pd
from scipy.stats import beta
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..') + '/'
def wilson(k, n, z=1.96):
    if n == 0: return [0, 0, 0]
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(p, 2), round(max(0, c - h), 2), round(min(1, c + h), 2)]
def summ(R, meth, strat):
    g = R[(R.method == meth) & (R.strategy == strat)]; pc = g[g['mode'] == 'pc']; nu = g[g['mode'] == 'null']
    out = {f'det_{int(round(100*d))}': wilson(int(x.detected.sum()), len(x)) for d, x in pc.groupby(pc.delta.round(2))}
    k = int((nu.n_rules > 0).sum()); n = len(nu)
    out.update(extra20=round(pc[pc.delta.round(2) == 0.2].false_rules.mean(), 2), null_mean_rules=round(nu.n_rules.mean(), 2),
               null_runs_with_rule=f'{k}/{n}', null_fp_upper95=round(float(beta.ppf(0.95, k + 1, n - k)) if k < n else 1.0, 3))
    return out
R2 = pd.read_csv(S + 'results/robustness2_main.csv', keep_default_na=False, na_values=[''])
R2['detected'] = R2.detected.astype(str).eq('True')
json.dump({f'{m}|{s}': summ(R2, m, s) for m in ['APR', 'FBH', 'FBHC', 'XAI'] for s in ['Reversal', 'Trend']},
          open(S + 'results/r1_summary.json', 'w'), indent=1)
BR = pd.read_csv(S + 'results/robustness2_brl.csv', keep_default_na=False, na_values=['']); BR['detected'] = BR.detected.astype(str).eq('True')
cand = {}
for m in BR.method.dropna().unique():
    nu = BR[(BR.method == m) & (BR['mode'] == 'null')]; cand[m] = ((nu.n_rules > 0).sum(), -BR[(BR.method == m) & (BR['mode'] == 'pc') & (BR.delta.round(2) == 0.15)].detected.mean())
best = min(cand, key=lambda k: cand[k])          # fewest null runs with rules, then highest 15-point detection
def b(s):
    g = BR[(BR.method == best) & (BR.strategy == s)]; pc = g[g['mode'] == 'pc']; nu = g[g['mode'] == 'null']
    d = lambda x: round(pc[pc.delta.round(2) == x].detected.mean(), 2)
    return f'{int((nu.n_rules > 0).sum())}/{len(nu)}', d(0.1), d(0.15), d(0.2), round(pc[pc.delta.round(2) == 0.2].false_rules.mean(), 1)
r, t = b('Reversal'), b('Trend')
json.dump(dict(best_method=best, rev_null=r[0], rev_d10=r[1], rev_d15=r[2], rev_d20=r[3], rev_extra=r[4],
               tr_null=t[0], tr_d10=t[1], tr_d15=t[2], tr_d20=t[3], tr_extra=t[4]), open(S + 'results/brl_summary.json', 'w'), indent=1)
G = pd.read_csv(S + 'results/robustness_runs.csv', keep_default_na=False, na_values=['']); G['detected'] = G.detected.astype(str).eq('True')
rows = []
for (s, m), g in G[G.method.str.startswith('XAI_m')].groupby(['strategy', 'method']):
    pc = g[g['mode'] == 'pc']; parts = m.split('_')
    rows.append(dict(strategy=s, method=m, det10=round(pc[pc.delta.round(2) == 0.1].detected.mean(), 2),
                     det15=round(pc[pc.delta.round(2) == 0.15].detected.mean(), 2), null_rules=round(g[g['mode'] == 'null'].n_rules.mean(), 2),
                     real_rules=float(g[g['mode'] == 'real'].n_rules.mean()), m=float(parts[1][1:]), g=float(parts[2][1:]), P=int(parts[3][1:])))
pd.DataFrame(rows).to_csv(S + 'results/sensitivity_summary.csv', index=False)
print('best BRL:', best)
