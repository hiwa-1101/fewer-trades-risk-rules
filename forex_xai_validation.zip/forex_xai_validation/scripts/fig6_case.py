"""Fig: rule R1 (2023-2025, M5, 14 pair x expert cells): change in net profit vs change in mean R, with random blocking."""
import glob, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import os
S=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
plt.rcParams.update({'font.family':'serif','font.size':7,'axes.linewidth':0.5,'xtick.major.width':0.5,'ytick.major.width':0.5})
D=pd.concat([pd.read_csv(f) for f in glob.glob(S+'r2325/W/MW2021_*_M5_*_R0.csv')]); D=D[D.outcome.isin(['SL','TP'])]
D['R']=D.profit/100; ab={'EURUSD':'EU','GBPUSD':'GU','USDJPY':'UJ','USDCHF':'UF','USDCAD':'UC','AUDUSD':'AU','NZDUSD':'NU'}
rng=np.random.default_rng(6); rows=[]
for (s,e),g in D.groupby(['symbol','expert']):
    f=g.R1.values==1; k=f.sum(); R=g.R.values; P=g.profit.values
    sims=np.array([np.delete(np.arange(len(g)),rng.choice(len(g),k,replace=False)) for _ in range(2000)])
    rows.append(dict(cell=f'{ab[s]}-{e}',dnet=-P[f].sum(),dR=R[~f].mean()-R.mean(),
                     rlo=np.percentile([R[i].mean()-R.mean() for i in sims],2.5),rhi=np.percentile([R[i].mean()-R.mean() for i in sims],97.5),
                     rnet=np.mean([-(P.sum()-P[i].sum()) for i in sims])))
T=pd.DataFrame(rows).sort_values('dnet').reset_index(drop=True); y=np.arange(len(T))
fig,ax=plt.subplots(1,2,figsize=(3.45,2.4),sharey=True)
ax[0].barh(y,T.dnet/1000,color='#1F4E79',height=0.6,label='R1')
ax[0].scatter(T.rnet/1000,y,marker='|',s=40,color='#7F7F7F',lw=1.2,label='random (mean)',zorder=3)
ax[0].axvline(0,color='#333',lw=0.5); ax[0].set_xlabel('Δ net profit (k USD)'); ax[0].set_title('(a) with vs. without rule',fontsize=7)
ax[0].set_yticks(y); ax[0].set_yticklabels(T.cell,fontsize=6)
ax[1].hlines(y,T.rlo,T.rhi,color='#BFBFBF',lw=3,label='random 95%')
ax[1].scatter(T.dR,y,color='#1F4E79',s=10,zorder=3,label='R1')
ax[1].axvline(0,color='#333',lw=0.5); ax[1].set_xlabel('Δ mean R per trade'); ax[1].set_title('(b) per-trade effect',fontsize=7)
for a in ax:
    a.grid(axis='x',lw=0.3,alpha=0.5); a.spines[['top','right']].set_visible(False)
h=[ax[0].containers[0],ax[0].collections[0],ax[1].collections[0]]
fig.legend(h,['rule R1','random blocking, mean','random blocking, 95% range'],loc='lower center',ncol=3,fontsize=5.3,frameon=False,columnspacing=0.8,handlelength=1.2)
fig.tight_layout(pad=0.3,w_pad=0.6,rect=(0,0.07,1,1)); fig.savefig(S+'results/fig6_case.png',dpi=300)
print(T.round(3).to_string()); print('better net:',(T.dnet>0).sum(),' dR inside random band:',((T.dR>=T.rlo)&(T.dR<=T.rhi)).sum())
