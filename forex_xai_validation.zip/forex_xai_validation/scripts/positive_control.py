"""
Positive-control and permutation-null validation of the Apriori-CART pre-trade filter.
Same pipeline and thresholds as forex_rule_analysis.py --relative.

Positive control: for a randomly chosen 2-item descriptor conjunction C (training support 5-12%),
win trades inside C are relabelled as losses with probability q = Δ/(1-p_C) in BOTH periods,
which raises the loss probability inside C by Δ percentage points. Δ in {0,5,10,15,20}.
Permutation null: training labels shuffled; count final rules.
"""
import os
import itertools, json, sys, warnings
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from mlxtend.frequent_patterns import apriori
from joblib import Parallel, delayed
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
F = ['PP', 'SRD', 'VR', 'PC', 'TL', 'CSC', 'UDF', 'MMD']

def load(f):
    d = pd.read_csv(S + f, parse_dates=['open_time'])
    tr = d.open_time < '2025'
    q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
    d['y'] = (d.outcome == 'SL').astype(int)
    I = pd.get_dummies(d[F].astype(str), prefix_sep='=').astype(bool)
    return d, I, tr.values

def covers(X, ante):
    m = np.ones(len(X), bool)
    for it in ante: m &= X[it].values
    return m

def pipeline(Xtr, ytr, strata, seed=42):
    base = ytr.mean(); min_conf = max(0.60, 1.1 * base); purity = min(0.95, base + 0.10)
    cand = {}
    for k, (_, idx) in enumerate(StratifiedKFold(8, shuffle=True, random_state=seed).split(Xtr, strata), 1):
        T = Xtr.iloc[idx].copy(); T['CLASS=SL'] = ytr[idx].astype(bool)
        fi = apriori(T, min_support=0.05, use_colnames=True)
        sup = {frozenset(s): v for s, v in zip(fi['itemsets'], fi['support'])}
        for s, v in sup.items():
            if 'CLASS=SL' in s and len(s) > 1:
                a = s - {'CLASS=SL'}
                if a in sup and v / sup[a] >= min_conf: cand.setdefault(frozenset(a), set()).add(k)
    ap = {r: p for r, p in cand.items() if len(p) >= 2}
    gs = GridSearchCV(DecisionTreeClassifier(random_state=seed), {'max_depth': [3, 4, 5, 6, 8], 'min_samples_leaf': [20, 40, 80]},
                      cv=10, scoring='roc_auc').fit(Xtr.values, ytr)
    tree = gs.best_estimator_; leaf = tree.apply(Xtr.values)
    pur = pd.Series(ytr).groupby(leaf).mean(); risky = set(pur[pur > purity].index); inr = np.isin(leaf, list(risky))
    hyb = {r: p for r, p in ap.items() if covers(Xtr, r).sum() and inr[covers(Xtr, r)].mean() >= 0.5}
    rules = dict(hyb); ch = True
    while ch:
        ch = False
        for r1, r2 in itertools.combinations(list(rules), 2):
            if r1 in rules and r2 in rules and len(r1 & r2) / len(r1 | r2) >= 0.8:
                g = r1 & r2; ps = rules.pop(r1) | rules.pop(r2); rules[g] = rules.get(g, set()) | ps; ch = True; break
    return list(rules), len(ap)

def one_run(name, f, conj, delta, seed):
    d, I, tr = load(f)
    rng = np.random.default_rng(seed)
    y = d.y.values.copy()
    inC = covers(I, conj)
    pC = y[inC & tr].mean()
    q = delta / (1 - pC) if delta > 0 else 0.0
    flip = inC & (y == 0) & (rng.random(len(y)) < q)
    y[flip] = 1
    Xtr = I[tr].reset_index(drop=True); ytr = y[tr]
    strata = (d.pair + d.timeframe)[tr].values
    rules, n_ap = pipeline(Xtr, ytr, strata)
    J = lambda r: len(set(r) & set(conj)) / len(set(r) | set(conj))
    hit = any(J(r) >= 0.5 for r in rules); false = sum(J(r) < 0.5 for r in rules)
    te = ~tr; Xte = I[te]; yte = y[te]
    rej = np.zeros(te.sum(), bool)
    for r in rules: rej |= covers(Xte, r)
    loss_all = yte.mean(); loss_kept = yte[~rej].mean() if (~rej).sum() else np.nan
    return dict(strategy=name, conj=' & '.join(conj), delta=delta, seed=seed, pC_train=round(pC, 3), n_apriori=n_ap,
                n_rules=len(rules), detected=hit, false_rules=false, test_rejected=int(rej.sum()),
                test_loss_all=round(loss_all, 4), test_loss_kept=round(loss_kept, 4), test_loss_rejected=round(yte[rej].mean(), 4) if rej.sum() else np.nan)

def null_run(name, f, seed):
    d, I, tr = load(f)
    rng = np.random.default_rng(seed)
    ytr = rng.permutation(d.y.values[tr])
    rules, n_ap = pipeline(I[tr].reset_index(drop=True), ytr, (d.pair + d.timeframe)[tr].values)
    return dict(strategy=name, seed=seed, n_apriori=n_ap, n_rules=len(rules))

if __name__ == '__main__':
    jobs, nulls = [], []
    for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
        d, I, tr = load(f)
        sup = {}
        items = list(I.columns)
        for a, b in itertools.combinations(items, 2):
            if a.split('=')[0] == b.split('=')[0]: continue
            s = covers(I[tr], (a, b)).mean()
            if 0.05 <= s <= 0.12: sup[(a, b)] = s
        keys = sorted(sup); rng = np.random.default_rng(2026)
        pick = [keys[i] for i in rng.choice(len(keys), 10, replace=False)]
        for c in pick:
            for delta in [0.0, 0.05, 0.10, 0.15, 0.20]:
                jobs.append((name, f, c, delta, 100 + len(jobs)))
        for s_ in range(10): nulls.append((name, f, 500 + s_))
    res = Parallel(n_jobs=2, verbose=0)(delayed(one_run)(*j) for j in jobs)
    nres = Parallel(n_jobs=2, verbose=0)(delayed(null_run)(*j) for j in nulls)
    R = pd.DataFrame(res); N = pd.DataFrame(nres)
    R.to_csv(S + 'results/positive_control_runs.csv', index=False); N.to_csv(S + 'results/permutation_null_runs.csv', index=False)
    summ = R.groupby(['strategy', 'delta']).agg(detect_rate=('detected', 'mean'), mean_rules=('n_rules', 'mean'),
            false_rules=('false_rules', 'mean'), loss_all=('test_loss_all', 'mean'), loss_kept=('test_loss_kept', 'mean'),
            rejected=('test_rejected', 'mean')).round(3)
    summ['loss_reduction_pp'] = ((summ.loss_all - summ.loss_kept) * 100).round(2)
    print(summ.to_string())
    print(N.groupby('strategy').agg(runs=('n_rules', 'size'), mean_rules=('n_rules', 'mean'), max_rules=('n_rules', 'max'), mean_apriori=('n_apriori', 'mean')))
    summ.to_csv(S + 'results/positive_control_summary.csv')
