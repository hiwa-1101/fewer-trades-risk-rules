"""White (2000) Reality Check and Hansen (2005) SPA test on the 60-configuration pre-trade filter grid (reversal rule),
selection period 2023-2024. Loss differential series: daily sum of net R of trades accepted by configuration k minus
benchmark (a) no trading (0) and (b) the unfiltered rule. Stationary bootstrap (Politis-Romano), mean block 10 days, B=5000."""
import os
import itertools, json, numpy as np, pandas as pd
S=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
d=pd.read_csv(S+'mw_all.csv',parse_dates=['open_time']); d['R']=d.net_pips/d.sl_pips; d['hour']=d.open_time.dt.hour
d=d[d.open_time<'2025'].copy(); d['day']=d.open_time.dt.normalize()
grid=list(itertools.product([0,9,12,16,22],[99,1.0,0.5],['all','06-18'],['all','High']))
def mk(x,c):
    mn,ms,ss,vr=c; m=(x.sl_pips>=mn)&(x.spread_pips<=ms)
    if ss=='06-18': m&=x.hour.between(6,17)
    if vr=='High': m&=x.VR.eq('High')
    return m
days=pd.Index(sorted(d.day.unique())); T=len(days)
base=d.groupby('day').R.sum().reindex(days,fill_value=0).values
P=np.column_stack([d[mk(d,g)].groupby('day').R.sum().reindex(days,fill_value=0).values for g in grid])
rng=np.random.default_rng(60); B=5000; q=0.1
def sb_index():
    idx=np.empty(T,int); idx[0]=rng.integers(T)
    for t in range(1,T): idx[t]=rng.integers(T) if rng.random()<q else (idx[t-1]+1)%T
    return idx
IDX=[sb_index() for _ in range(B)]
def tests(D):
    n=len(D); dbar=D.mean(0)
    bm=np.array([D[i].mean(0) for i in IDX])                   # B x K
    om=np.sqrt(n)*bm.std(0); om[om==0]=1e-12
    # White RC (non-studentized)
    V=np.sqrt(n)*dbar.max(); Vb=np.sqrt(n)*(bm-dbar).max(1); p_rc=(Vb>=V).mean()
    # Hansen SPA (studentized, consistent recentering)
    Tspa=max(0,(np.sqrt(n)*dbar/om).max())
    thr=-np.sqrt(2*np.log(np.log(n)))*om/np.sqrt(n)
    mu=np.where(dbar>=thr,dbar,0)
    Tb=np.maximum(0,(np.sqrt(n)*(bm-mu)/om).max(1)); p_spa=(Tb>=Tspa).mean()
    k=int(np.argmax(dbar/ (om/np.sqrt(n))))
    return dict(p_RC=round(float(p_rc),3),p_SPA=round(float(p_spa),3),best_config=str(grid[k]),best_mean_daily_R=round(float(dbar[k]),4))
out=dict(n_days=T,n_configs=len(grid),vs_no_trading=tests(P),vs_unfiltered=tests(P-base[:,None]))
json.dump(out,open(S+'results/spa.json','w'),indent=1); print(json.dumps(out,indent=1))
