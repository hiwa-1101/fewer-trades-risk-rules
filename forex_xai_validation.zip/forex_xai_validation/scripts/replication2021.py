"""Replication of the authors' earlier (unpublished, 2021) with/without-rule evaluation.
Data: MW2021_EA (MT5, Alpari real ticks), M5, 7 major pairs, experts M (sell) and W (buy), 2021-05-21..2021-07-21.
Rules R1..R5 are those of the 2021 study (fixed; not re-learned). Primary window = 2021 test month (06-21..07-21)."""
import os
import glob, json
import numpy as np, pandas as pd
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
MAJ = ['EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'USDCAD', 'AUDUSD', 'NZDUSD']
D = pd.concat([pd.read_csv(f) for f in glob.glob(S + 'r2021/MW2021_*_M_R0.csv') + glob.glob(S + 'r2021/W/MW2021_*_W_R0.csv')])
D = D[D.symbol.isin(MAJ) & D.outcome.isin(['SL', 'TP'])].copy()
D['t'] = pd.to_datetime(D.open_time, format='%Y.%m.%d %H:%M'); D['R'] = D.profit / 100.0; D['day'] = D.t.dt.normalize()
D['cell'] = D.symbol + '_' + D.expert
rng = np.random.default_rng(2021)
OUT = {}

def analyse(T, label, B=4000):
    res = dict(n=len(T), win=round((T.outcome == 'TP').mean(), 3), R=round(T.R.mean(), 3), net=round(T.profit.sum(), 0),
               by_expert={e: dict(n=int(len(g)), R=round(g.R.mean(), 3), net=round(g.profit.sum(), 0)) for e, g in T.groupby('expert')},
               rules={})
    days = T.day.unique(); di = {d: i for i, d in enumerate(days)}; idx = T.day.map(di).values
    for k in range(1, 6):
        f = (T[f'R{k}'] == 1).values
        if f.sum() == 0:
            res['rules'][k] = dict(fires=0); continue
        kept = T[~f]
        # paper-style: cells (pair x expert) whose net profit rises / falls / stays
        cells = T.groupby('cell').apply(lambda g: (g[g[f'R{k}'] == 0].profit.sum() - g.profit.sum()))
        imp, wor, same = int((cells > 1e-9).sum()), int((cells < -1e-9).sum()), int((abs(cells) <= 1e-9).sum())
        # random blocking of the same number of trades in each cell (null for the paper-style count and for R kept)
        nb = T.assign(f=f).groupby('cell').f.sum()
        sim_imp, sim_R = [], []
        for _ in range(B):
            keepmask = np.ones(len(T), bool); im = 0
            for c, g in T.groupby('cell'):
                kc = int(nb[c])
                if kc == 0: continue
                pos = np.flatnonzero((T.cell == c).values); drop = rng.choice(pos, kc, replace=False); keepmask[drop] = False
                im += T.profit.values[drop].sum() < 0          # cell net rises iff blocked trades sum to a loss
            sim_imp.append(im); sim_R.append(T.R.values[keepmask].mean())
        sim_R = np.array(sim_R)
        # day-block bootstrap CI of delta R (kept minus all)
        sa = np.bincount(idx, T.R.values); na = np.bincount(idx); sk = np.bincount(idx, T.R.values * ~f); nk = np.bincount(idx, (~f).astype(float))
        bs = []
        for _ in range(B):
            i = rng.integers(0, len(days), len(days))
            if nk[i].sum(): bs.append(sk[i].sum() / nk[i].sum() - sa[i].sum() / na[i].sum())
        res['rules'][k] = dict(fires=int(f.sum()), loss_fired=round((T[f].outcome == 'SL').mean(), 3),
                               loss_rest=round((kept.outcome == 'SL').mean(), 3),
                               cells_fired=int((nb > 0).sum()), cells_improved=imp, cells_worse=wor, cells_same=same,
                               random_cells_improved_mean=round(float(np.mean(sim_imp)), 1),
                               net_all=round(T.profit.sum(), 0), net_kept=round(kept.profit.sum(), 0),
                               R_all=round(T.R.mean(), 3), R_kept=round(kept.R.mean(), 3),
                               dR_ci=[round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)],
                               p_random=round(float((sim_R >= kept.R.mean()).mean()), 3))
    OUT[label] = res

analyse(D[D.t >= '2021-06-21'], 'test_month')
analyse(D, 'both_months')
json.dump(OUT, open(S + 'results/replication2021.json', 'w'), indent=1, default=str)
for lab, r in OUT.items():
    print('==', lab, {k: v for k, v in r.items() if k != 'rules'})
    for k, v in r['rules'].items(): print('  R%d' % k, v)
