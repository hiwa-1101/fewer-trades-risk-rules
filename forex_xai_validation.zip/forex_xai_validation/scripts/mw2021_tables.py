"""Builds tables in the format of the 2021 paper (sl-w, tp-w, net, sl-m, tp-m, net) from MW2021_*.csv logs.
Usage:  python mw2021_tables.py <folder with MW2021_*.csv> [from_date] [to_date]
Outputs: mw2021_runs.csv (one row per symbol/expert/rule run), mw2021_paper_tables.csv (paper layout),
         mw2021_expost.csv (effect of each rule computed from the normal R0 runs, for comparison)."""
import sys, glob, os
import pandas as pd

folder = sys.argv[1] if len(sys.argv) > 1 else '.'
d0 = sys.argv[2] if len(sys.argv) > 2 else None
d1 = sys.argv[3] if len(sys.argv) > 3 else None
D = pd.concat([pd.read_csv(f) for f in glob.glob(os.path.join(folder, 'MW2021_*.csv'))], ignore_index=True)
D['open_time'] = pd.to_datetime(D.open_time, format='%Y.%m.%d %H:%M')
if d0: D = D[D.open_time >= d0]
if d1: D = D[D.open_time < d1]
T = D[D.outcome.isin(['SL', 'TP'])]

runs = (T.groupby(['symbol', 'tf', 'expert', 'rule_run'])
          .agg(sl=('outcome', lambda s: (s == 'SL').sum()), tp=('outcome', lambda s: (s == 'TP').sum()),
               net=('profit', 'sum')).reset_index())
blk = D[D.outcome == 'BLOCKED'].groupby(['symbol', 'tf', 'expert', 'rule_run']).size().rename('blocked')
runs = runs.merge(blk, how='left', on=['symbol', 'tf', 'expert', 'rule_run']).fillna({'blocked': 0})
runs.to_csv('mw2021_runs.csv', index=False)

rows = []
for (sym, tf, rule), g in runs.groupby(['symbol', 'tf', 'rule_run']):
    w = g[g.expert == 'W']; m = g[g.expert == 'M']
    f = lambda x, c: (int(x[c].iloc[0]) if c != 'net' else round(float(x[c].iloc[0]), 2)) if len(x) else ''
    rows.append(dict(symbol=sym, tf=tf, rule=('M and W' if rule == 0 else f'Rule{rule}'),
                     **{'sl-w': f(w, 'sl'), 'tp-w': f(w, 'tp'), 'net-w': f(w, 'net'),
                        'sl-m': f(m, 'sl'), 'tp-m': f(m, 'tp'), 'net-m': f(m, 'net')}))
P = pd.DataFrame(rows).sort_values(['symbol', 'rule'])
P.to_csv('mw2021_paper_tables.csv', index=False)
print(P.to_string(index=False))

# ex-post effect of each rule on the normal runs (approximation: skipping a trade can free the slot for another one)
N = T[T.rule_run == 0]
ex = []
for k in range(1, 6):
    for (sym, e), g in N.groupby(['symbol', 'expert']):
        keep = g[g[f'R{k}'] == 0]
        ex.append(dict(rule=k, symbol=sym, expert=e, trades=len(g), blocked=len(g) - len(keep),
                       net_all=round(g.profit.sum(), 2), net_kept=round(keep.profit.sum(), 2),
                       sl_blocked=int((g[g[f'R{k}'] == 1].outcome == 'SL').sum()),
                       tp_blocked=int((g[g[f'R{k}'] == 1].outcome == 'TP').sum())))
pd.DataFrame(ex).to_csv('mw2021_expost.csv', index=False)
print('\nNormal-run trades:', len(N), '| rule-run files:', sorted(T.rule_run.unique().tolist()))
