"""Step 3: day-block bootstrap CIs, Holm-adjusted tests, walk-forward evaluation."""
import sys, json, warnings
import os
import numpy as np, pandas as pd
from scipy.stats import mannwhitneyu
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
warnings.filterwarnings('ignore')
S = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
sys.path.insert(0, S + 'scripts'); sys.argv = ['x']
import robustness as rb
rng = np.random.default_rng(11)

def holm(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for k, i in enumerate(o):
        run = max(run, min(1, (m - k) * p[i])); adj[i] = run
    return adj

def block_boot(g, B=5000):
    day = g.open_time.dt.normalize().values
    days, inv = np.unique(day, return_inverse=True)
    sums = np.bincount(inv, weights=g.R.values); cnts = np.bincount(inv)
    nd = len(days); out = np.empty(B)
    for b in range(B):
        i = rng.integers(0, nd, nd); out[b] = sums[i].sum() / cnts[i].sum()
    return out

cm = pd.read_csv(S + 'combined_trades.csv', parse_dates=['open_time', 'exit_time'])
rows = []
cells = []
for (s, t, p), g in cm.groupby(['strategy', 'timeframe', 'period']):
    bs = block_boot(g); iid = g.R.values[rng.integers(0, len(g), (3000, len(g)))].mean(1)
    pval = min(1, 2 * min((bs <= 0).mean(), (bs >= 0).mean()))
    rows.append(dict(strategy=s, tf=t, period=p, n=len(g), R=round(g.R.mean(), 3),
                     ci_block=[round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)],
                     ci_iid=[round(np.percentile(iid, 2.5), 3), round(np.percentile(iid, 97.5), 3)], p_block=pval))
T = pd.DataFrame(rows); T['p_holm'] = holm(T.p_block.values).round(4)
# pooled 2023-25 per strategy x tf
pooled = []
for (s, t), g in cm.groupby(['strategy', 'timeframe']):
    bs = block_boot(g)
    pooled.append(dict(strategy=s, tf=t, R=round(g.R.mean(), 3), ci_block=[round(np.percentile(bs, 2.5), 3), round(np.percentile(bs, 97.5), 3)]))
# between-strategy comparisons (8)
comp = []
for t in ['M5', 'M15', 'H1', 'H4']:
    for p in ['2023-24', '2025']:
        a = cm[(cm.strategy == 'Trend') & (cm.timeframe == t) & (cm.period == p)].R
        b = cm[(cm.strategy == 'Reversal') & (cm.timeframe == t) & (cm.period == p)].R
        comp.append(dict(tf=t, period=p, p_mwu=mannwhitneyu(a, b).pvalue))
C = pd.DataFrame(comp); C['p_holm'] = holm(C.p_mwu.values)

# walk-forward
def fold(f, train_end, test_year):
    d = pd.read_csv(S + f, parse_dates=['open_time'])
    tr = (d.open_time < train_end).values; te = (d.open_time.dt.year == test_year).values
    q1, q2 = d.loc[tr, 'mmd_raw'].quantile([1 / 3, 2 / 3])
    d['MMD'] = np.where(d.mmd_raw < q1, 'Low', np.where(d.mmd_raw > q2, 'High', 'Middle'))
    y = (d.outcome == 'SL').astype(int).values
    I = pd.get_dummies(d[rb.F].astype(str), prefix_sep='=').astype(bool)
    Xtr = I[tr].reset_index(drop=True)
    A = rb.artifacts(Xtr, y[tr], (d.pair + d.timeframe)[tr].values)
    rules = rb.xai_rules(A, 1.10, 0.10, 2)
    apr = rb.xai_rules(A, 1.10, 0.10, 2, use_cart=False)
    lr = LogisticRegression(max_iter=3000).fit(I[tr].astype(int), y[tr])
    auc = roc_auc_score(y[te], lr.predict_proba(I[te].astype(int))[:, 1])
    rej = np.zeros(te.sum(), bool)
    for r in apr: rej |= rb.covers(I[te], r)
    R = (d.net_pips / d.sl_pips).values
    return dict(n_train=int(tr.sum()), n_test=int(te.sum()), base_train=round(y[tr].mean(), 3), base_test=round(y[te].mean(), 3),
                apriori_candidates=len(apr), final_rules=len(rules), test_auc_logit=round(auc, 3),
                apr_only_rejected_share=round(rej.mean(), 3), apr_only_loss_kept=round(y[te][~rej].mean(), 3) if (~rej).sum() else None,
                test_meanR=round(R[te].mean(), 3))
WF = {}
for name, f in [('Reversal', 'mw_all.csv'), ('Trend', 'tf_all.csv')]:
    WF[name] = {'2023->2024': fold(f, '2024-01-01', 2024), '2023-24->2025': fold(f, '2025-01-01', 2025)}

out = dict(cells=T.to_dict('records'), pooled=pooled, comparisons=C.round(4).to_dict('records'), walk_forward=WF)
json.dump(out, open(S + 'results/step3_stats.json', 'w'), indent=1, default=str)
pd.set_option('display.width', 200)
print(T.to_string(index=False)); print(pd.DataFrame(pooled).to_string(index=False)); print(C.round(4).to_string(index=False))
print(json.dumps(WF, indent=1))
