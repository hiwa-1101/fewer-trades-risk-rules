#!/usr/bin/env python3
"""
Pre-registered exit-parameter selection for MW_RiskLogger v1.10 optimisation runs.

RULE (fixed before looking at any results):
  * pool all pairs and timeframes for each (exit_variant, sl_buffer) combination;
  * selection uses ONLY 2023 and 2024: score = min(mean net R in 2023, mean net R in 2024),
    with at least 500 trades in each year;
  * the combination with the highest score is LOCKED;
  * 2025 is evaluated ONCE for the locked combination (bootstrap 95% CI on mean R).

Usage: python3 opt_select.py <folder with MW_trades_*_X*_B*.csv>
"""
import glob, os, sys
import numpy as np, pandas as pd

folder = sys.argv[1] if len(sys.argv) > 1 else '.'
files = glob.glob(os.path.join(folder, 'MW_trades_*_X*_B*.csv'))
if not files:
    sys.exit('no optimisation files found')
d = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
d['open_time'] = pd.to_datetime(d['open_time'])
d = d[d['outcome'].isin(['SL', 'TP'])].copy()
d['R'] = d['net_pips'] / d['sl_pips']
d['yr'] = d['open_time'].dt.year
NAMES = {0: 'RR 1.0', 1: 'RR 1.5', 2: 'RR 2.0', 3: 'RR 3.0', 4: 'measured move'}

g = d[d.yr <= 2024].groupby(['exit_variant', 'sl_buffer', 'yr'])['R'].agg(['size', 'mean']).unstack('yr')
g.columns = [f'{a}_{b}' for a, b in g.columns]
g['score'] = g[['mean_2023', 'mean_2024']].min(axis=1)
g = g[(g['size_2023'] >= 500) & (g['size_2024'] >= 500)].sort_values('score', ascending=False)
print('TRAINING-PERIOD TABLE (2023, 2024 only):')
print(g.round(4).to_string(), '\n')
v, b = g.index[0]
print(f'LOCKED: exit = {NAMES[int(v)]}, SL buffer = {b} pips   (worst-year mean R = {g.iloc[0]["score"]:.4f})')

t = d[(d.exit_variant == v) & (d.sl_buffer == b) & (d.yr == 2025)]
rng = np.random.default_rng(0)
bs = [t.R.values[rng.integers(0, len(t), len(t))].mean() for _ in range(10000)]
pf = t.net_pips[t.net_pips > 0].sum() / -t.net_pips[t.net_pips < 0].sum()
print(f'\nTEST 2025 (single evaluation): n={len(t)}  SL rate={(t.outcome == "SL").mean():.3f}  '
      f'mean R={t.R.mean():.4f}  95% CI=[{np.percentile(bs, 2.5):.4f}, {np.percentile(bs, 97.5):.4f}]  '
      f'PF={pf:.3f}  net pips={t.net_pips.sum():.0f}')
print(t.groupby(['pair', 'timeframe']).agg(n=('R', 'size'), mean_R=('R', 'mean'), pips=('net_pips', 'sum')).round(3).to_string())
