#!/usr/bin/env python3
"""
Merge the 9 CSV files written by MW_RiskLogger.mq5 into trades.csv
for forex_rule_analysis.py, and print a data audit.

Usage: python3 merge_mt5_logs.py  "C:/Users/<you>/AppData/Roaming/MetaQuotes/Terminal/Common/Files"  [prefix]
       prefix = MW_trades (default, reversal EA) or TF_trades (trend-following EA)
"""
import glob, os, sys
import pandas as pd

folder = sys.argv[1] if len(sys.argv) > 1 else '.'
prefix = sys.argv[2] if len(sys.argv) > 2 else 'MW_trades'
files = sorted(f for f in glob.glob(os.path.join(folder, prefix + '_*.csv')) if '_X' not in os.path.basename(f))
if not files:
    sys.exit(f'No {prefix}_*.csv files found in ' + folder)
df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
df['pair'] = df['pair'].str.upper().str[:6]            # strip broker suffixes (EURUSDm -> EURUSD)
df['open_time'] = pd.to_datetime(df['open_time'])
df = df[df['outcome'].isin(['SL', 'TP'])].sort_values('open_time').reset_index(drop=True)
df.to_csv('trades.csv', index=False)

print(f'files: {len(files)}   trades: {len(df)}   span: {df.open_time.min()} -> {df.open_time.max()}\n')
print('Trades per pair x timeframe x year:')
print(pd.crosstab([df.pair, df.timeframe], df.open_time.dt.year, margins=True), '\n')
print('SL rate per pair x timeframe (%):')
print((df.assign(sl=df.outcome.eq('SL')).pivot_table(index='pair', columns='timeframe', values='sl') * 100).round(1), '\n')
print(f"Mean spread at entry (pips): {df.spread_pips.mean():.2f}   mean SL distance (pips): {df.sl_pips.mean():.1f}")
print(f"Net pips total: {df.net_pips.sum():.1f}   win rate: {100 * df.outcome.eq('TP').mean():.1f}%")
print(f"UDF raw median: {df.udf_raw.median()}  (threshold in EA: High if >= 14)")
for col in ['PP', 'SRD', 'VR', 'PC', 'TL', 'CSC', 'UDF', 'MMD']:
    print(f'{col}: ' + ', '.join(f'{k}={v:.0%}' for k, v in df[col].value_counts(normalize=True).items()))
print('\nWritten: trades.csv  ->  python3 forex_rule_analysis.py trades.csv --test-start 2025-01-01')
