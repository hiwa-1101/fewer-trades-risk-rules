"""Pre-registered confirmation (results/preregistration_R1_2026-11-01.md) of 2021 rules on 2023-2025, MW2021_EA, 7 majors."""
import glob, json, numpy as np, pandas as pd
import os
S=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '')
D=pd.concat([pd.read_csv(f) for f in glob.glob(S+'r2325/W/**/MW2021_*_R0.csv',recursive=True)])
D=D[D.outcome.isin(['SL','TP'])].copy()
D['t']=pd.to_datetime(D.open_time,format='%Y.%m.%d %H:%M'); D['R']=D.profit/100; D['day']=D.t.dt.normalize(); D['cell']=D.symbol+'_'+D.expert
rng=np.random.default_rng(2325); B=2000; OUT={}
def test(T,k):
    f=(T[f'R{k}']==1).values; kept=T[~f]
    days=T.day.unique(); di={d:i for i,d in enumerate(days)}; idx=T.day.map(di).values
    sa=np.bincount(idx,T.R.values); na=np.bincount(idx); sk=np.bincount(idx,T.R.values*~f); nk=np.bincount(idx,(~f).astype(float))
    bs=[]
    for _ in range(B):
        i=rng.integers(0,len(days),len(days)); bs.append(sk[i].sum()/nk[i].sum()-sa[i].sum()/na[i].sum())
    cells=T.cell.values; nb=pd.Series(f).groupby(cells).sum(); pos={c:np.flatnonzero(cells==c) for c in nb.index}
    simR=[]
    for _ in range(B):
        m=np.ones(len(T),bool)
        for c,n in nb.items():
            if n: m[rng.choice(pos[c],int(n),replace=False)]=False
        simR.append(T.R.values[m].mean())
    cimp=T.assign(f=f).groupby('cell').apply(lambda g: g[~g.f].profit.sum()-g.profit.sum())
    return dict(n=len(T),fires=int(f.sum()),loss_fired=round((T[f].outcome=='SL').mean(),3),loss_rest=round((kept.outcome=='SL').mean(),3),
        R_all=round(T.R.mean(),4),R_kept=round(kept.R.mean(),4),dR=round(kept.R.mean()-T.R.mean(),4),
        dR_ci=[round(np.percentile(bs,2.5),4),round(np.percentile(bs,97.5),4)],
        p_random=round(float((np.array(simR)>=kept.R.mean()).mean()),4),
        net_all=round(T.profit.sum()),net_kept=round(kept.profit.sum()),cells_improved=int((cimp>1e-9).sum()),cells=len(cimp))
OUT['overall']=dict(n=len(D),R=round(D.R.mean(),4),win=round((D.outcome=='TP').mean(),3),net=round(D.profit.sum()),
    by_expert={e:dict(n=len(g),R=round(g.R.mean(),4)) for e,g in D.groupby('expert')},
    by_year={str(y):dict(n=len(g),R=round(g.R.mean(),4)) for y,g in D.groupby(D.t.dt.year)},
    last_trade={c:str(g.t.max().date()) for c,g in D.groupby('cell')})
OUT['primary_R1']=test(D,1)
sec={k:test(D,k) for k in (2,4)}; p=[sec[2]['p_random'],sec[4]['p_random']]
o=np.argsort(p); adj=[0,0]; run=0
for r,i in enumerate(o): run=max(run,min(1,(2-r)*p[i])); adj[i]=run
sec[2]['p_holm'],sec[4]['p_holm']=adj; OUT['secondary']=sec
OUT['R1_by_year']={str(y):test(g,1) for y,g in D.groupby(D.t.dt.year)}
OUT['R1_by_expert']={e:test(g,1) for e,g in D.groupby('expert')}
OUT['rare']={k:int((D[f'R{k}']==1).sum()) for k in (3,5)}
json.dump(OUT,open(S+'results/confirm2325.json','w'),indent=1,default=str)
print(json.dumps(OUT,indent=1,default=str))
