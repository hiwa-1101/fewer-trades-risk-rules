//+------------------------------------------------------------------+
//|                                                 TF_XAI_Logger.mq5 |
//|  Research logger: Donchian trend-following with ATR chandelier     |
//|  exit, daily-EMA trend filter, and the 8 explainable pre-trade     |
//|  descriptors of Table I logged at every entry.                     |
//|                                                                   |
//|  - Long : D1 close > D1 EMA(50) and H-bar close > highest high of  |
//|           the previous 55 bars                                     |
//|  - Short: D1 close < D1 EMA(50) and close < lowest low of 55 bars  |
//|  - Initial stop: 2 x ATR(14); trailing (chandelier) stop: best     |
//|    price -/+ 3 x ATR(14); no fixed take-profit                     |
//|  - Virtual trades only (no orders); exits checked on every tick    |
//|  - Parameters are FIXED a priori (classic values) - do not optimise |
//+------------------------------------------------------------------+
#property copyright   "H. Hassanzadeh, E. Khezri"
#property version     "1.00"
#property description "Research logger - trend following, virtual trades only."

//--- strategy (fixed a priori)
input int             InpEntryBars      = 55;          // Donchian entry channel (bars)
input int             InpATRPeriod      = 14;          // ATR period
input double          InpInitStopATR    = 2.0;         // Initial stop = x * ATR
input double          InpTrailATR       = 3.0;         // Chandelier trail = x * ATR from best price
input ENUM_TIMEFRAMES InpTrendTF        = PERIOD_D1;   // Trend-filter timeframe
input int             InpTrendEMA       = 50;          // Trend-filter EMA period
input double          InpCommPerLotSide = 3.0;         // Commission, account currency per lot per side
//--- descriptors (Table I)
input int    InpSRStrength      = 10;
input int    InpSRDays          = 5;
input double InpSRThresholdPips = 20.0;
input double InpVRHigh          = 1.20;
input double InpPCThreshold     = 0.20;
input double InpCSCHigh         = 1.50;
input double InpCSCLow          = 0.80;
input int    InpUDFHigh         = 14;
input double InpMMDHigh         = 1.00;
input double InpMMDLow          = 0.50;
input string InpFilePrefix      = "TF_trades";

struct VTrade
  {
   int               dir;        // +1 long, -1 short
   double            entry;
   double            sl;         // current (trailing) stop
   double            initPips;   // initial risk in pips (1R)
   double            best;       // best price since entry
  };

VTrade   g_trades[];
string   g_rows[];
double   g_pip     = 0.0;
double   g_atrNow  = 0.0;
int      g_atr     = INVALID_HANDLE;
int      g_ema     = INVALID_HANDLE;
int      g_file    = INVALID_HANDLE;
datetime g_lastBar = 0;
string   g_tf      = "";
int      g_logged  = 0;
double   g_sumR    = 0.0;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_pip = (_Digits == 3 || _Digits == 5) ? 10.0 * _Point : _Point;
   g_tf  = StringSubstr(EnumToString(Period()), 7);
   g_atr = iATR(_Symbol, Period(), InpATRPeriod);
   g_ema = iMA(_Symbol, InpTrendTF, InpTrendEMA, 0, MODE_EMA, PRICE_CLOSE);
   if(g_atr == INVALID_HANDLE || g_ema == INVALID_HANDLE)
      return(INIT_FAILED);
   string name = InpFilePrefix + "_" + _Symbol + "_" + g_tf + ".csv";
   g_file = FileOpen(name, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(g_file == INVALID_HANDLE)
     {
      Print("Cannot open ", name, ", error ", GetLastError());
      return(INIT_FAILED);
     }
   FileWriteString(g_file,
      "open_time,pair,timeframe,pattern,PP,SRD,VR,PC,TL,CSC,UDF,MMD,"
      "pp_raw,res_dist_pips,sup_dist_pips,vr_raw,pc_raw,csc_raw,udf_raw,mmd_raw,"
      "entry,sl,tp,sl_pips,spread_pips,exit_time,outcome,gross_pips,net_pips,R\r\n");
   return(INIT_SUCCEEDED);
  }

double OnTester()
  {
   return(g_sumR);
  }

void OnDeinit(const int reason)
  {
   PrintFormat("%s %s: %d trades logged, %d still open at end of test (not logged), sum R = %.2f",
               _Symbol, g_tf, g_logged, ArraySize(g_trades), g_sumR);
   if(g_file != INVALID_HANDLE) FileClose(g_file);
   if(g_atr != INVALID_HANDLE)  IndicatorRelease(g_atr);
   if(g_ema != INVALID_HANDLE)  IndicatorRelease(g_ema);
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   MqlTick tk;
   if(!SymbolInfoTick(_Symbol, tk))
      return;
   ManageTrades(tk);
   datetime bt = iTime(_Symbol, Period(), 0);
   if(bt == g_lastBar)
      return;
   g_lastBar = bt;

   double atr[];
   if(CopyBuffer(g_atr, 0, 1, 1, atr) != 1 || atr[0] <= 0.0)
      return;
   g_atrNow = atr[0];

   int n = InpEntryBars + 3;
   int needSR = InpSRDays * BarsPerDay() + InpSRStrength + 2;
   if(Bars(_Symbol, Period()) < MathMax(n, needSR) + 10)
      return;
   double h[], l[], c[];
   ArraySetAsSeries(h, true);
   ArraySetAsSeries(l, true);
   ArraySetAsSeries(c, true);
   if(CopyHigh(_Symbol, Period(), 0, n, h) != n ||
      CopyLow(_Symbol, Period(), 0, n, l) != n ||
      CopyClose(_Symbol, Period(), 0, n, c) != n)
      return;
   double hh = h[2], ll = l[2];
   for(int i = 2; i <= InpEntryBars + 1; i++)
     {
      hh = MathMax(hh, h[i]);
      ll = MathMin(ll, l[i]);
     }
   //--- daily trend filter (last completed D1 bar)
   double ema[];
   if(CopyBuffer(g_ema, 0, 1, 1, ema) != 1)
      return;
   double dClose = iClose(_Symbol, InpTrendTF, 1);
   if(dClose <= 0.0)
      return;
   int trend = (dClose > ema[0]) ? 1 : ((dClose < ema[0]) ? -1 : 0);

   if(trend == 1 && c[1] > hh && !HasOpen(1))
      OpenTrade(1, hh - ll, tk);
   if(trend == -1 && c[1] < ll && !HasOpen(-1))
      OpenTrade(-1, hh - ll, tk);
  }

//+------------------------------------------------------------------+
bool HasOpen(const int dir)
  {
   for(int i = 0; i < ArraySize(g_trades); i++)
      if(g_trades[i].dir == dir) return(true);
   return(false);
  }

void OpenTrade(const int dir, const double chanHeight, const MqlTick &tk)
  {
   double entry    = (dir > 0) ? tk.ask : tk.bid;
   double stopDist = InpInitStopATR * g_atrNow;
   double sl       = entry - dir * stopDist;
   string row = BuildRow(dir, g_atrNow, chanHeight, entry, sl, 0.0, stopDist, tk);
   if(row == "")
      return;
   int sz = ArraySize(g_trades);
   ArrayResize(g_trades, sz + 1);
   ArrayResize(g_rows, sz + 1);
   g_trades[sz].dir      = dir;
   g_trades[sz].entry    = entry;
   g_trades[sz].sl       = sl;
   g_trades[sz].initPips = stopDist / g_pip;
   g_trades[sz].best     = (dir > 0) ? tk.bid : tk.ask;
   g_rows[sz]            = row;
  }

//+------------------------------------------------------------------+
//| Chandelier trailing stop and exit check on every tick            |
//+------------------------------------------------------------------+
void ManageTrades(const MqlTick &tk)
  {
   for(int i = ArraySize(g_trades) - 1; i >= 0; i--)
     {
      double exitPx = 0.0;
      if(g_trades[i].dir > 0)                       // long: exits at Bid
        {
         if(tk.bid > g_trades[i].best) g_trades[i].best = tk.bid;
         double trail = g_trades[i].best - InpTrailATR * g_atrNow;
         if(trail > g_trades[i].sl) g_trades[i].sl = trail;
         if(tk.bid <= g_trades[i].sl) exitPx = tk.bid;
        }
      else                                          // short: exits at Ask
        {
         if(tk.ask < g_trades[i].best) g_trades[i].best = tk.ask;
         double trail = g_trades[i].best + InpTrailATR * g_atrNow;
         if(trail < g_trades[i].sl) g_trades[i].sl = trail;
         if(tk.ask >= g_trades[i].sl) exitPx = tk.ask;
        }
      if(exitPx == 0.0)
         continue;
      double gross = g_trades[i].dir * (exitPx - g_trades[i].entry) / g_pip;
      double net   = gross - CommissionPips();
      double R     = net / g_trades[i].initPips;
      string outcome = (net > 0.0) ? "TP" : "SL";      // TP = profitable exit, SL = losing exit
      FileWriteString(g_file, g_rows[i] + "," + TimeStr(tk.time) + "," + outcome + "," +
                      DoubleToString(gross, 1) + "," + DoubleToString(net, 1) + "," +
                      DoubleToString(R, 3) + "\r\n");
      FileFlush(g_file);
      g_sumR += R;
      g_logged++;
      RemoveTrade(i);
     }
  }

//+------------------------------------------------------------------+
//| The 8 descriptors of Table I at the entry candle                 |
//| (MMD here = Donchian channel height / ATR)                       |
//+------------------------------------------------------------------+
string BuildRow(const int dir, const double a, const double height, const double entry,
                const double sl, const double tp, const double slDist, const MqlTick &tk)
  {
   int n24  = BarsPerDay();
   int sr   = InpSRStrength;
   int need = MathMax(InpSRDays * n24 + sr + 2, 40);
   double o[], h[], l[], c[];
   ArraySetAsSeries(o, true);
   ArraySetAsSeries(h, true);
   ArraySetAsSeries(l, true);
   ArraySetAsSeries(c, true);
   if(CopyOpen(_Symbol, Period(), 0, need, o) != need ||
      CopyHigh(_Symbol, Period(), 0, need, h) != need ||
      CopyLow(_Symbol, Period(), 0, need, l) != need ||
      CopyClose(_Symbol, Period(), 0, need, c) != need)
      return("");
   double c1 = c[1];
   //--- 1) PP
   double hi = h[1], lo = l[1];
   for(int i = 1; i <= n24; i++) { hi = MathMax(hi, h[i]); lo = MathMin(lo, l[i]); }
   double pp = (hi > lo) ? (c1 - lo) / (hi - lo) : 0.5;
   string PP = (pp < 0.333) ? "Lower" : ((pp > 0.667) ? "Upper" : "Middle");
   //--- 2) SRD
   double res = DBL_MAX, sup = DBL_MAX;
   for(int i = sr + 1; i <= InpSRDays * n24 && i < need - sr; i++)
     {
      if(IsPivotHigh(h, i, sr, need) && h[i] > c1) res = MathMin(res, (h[i] - c1) / g_pip);
      if(IsPivotLow(l, i, sr, need)  && l[i] < c1) sup = MathMin(sup, (c1 - l[i]) / g_pip);
     }
   bool nearR = (res <= InpSRThresholdPips), nearS = (sup <= InpSRThresholdPips);
   string SRD = "N";
   if(nearR && (!nearS || res <= sup)) SRD = "R";
   else if(nearS)                       SRD = "S";
   //--- 3) VR
   double vr = VolumeRate();
   string VR = (vr >= InpVRHigh) ? "High" : "Low";
   //--- 4) PC
   int bull = 0, bear = 0;
   for(int i = 1; i <= 10; i++) { if(c[i] > o[i]) bull++; else if(c[i] < o[i]) bear++; }
   double pc = (bull - bear) / 10.0;
   string PC = (pc > InpPCThreshold) ? "Bullish" : ((pc < -InpPCThreshold) ? "Bearish" : "Neutral");
   //--- 5) TL (20 candles, 7/7/6 segments)
   string TL = (c[14] > o[20] ? "U" : "D");
   TL += (c[7] > o[13] ? "U" : "D");
   TL += (c[1] > o[6] ? "U" : "D");
   //--- 6) CSC
   double avg = 0.0;
   for(int i = 2; i <= 15; i++) avg += h[i] - l[i];
   avg /= 14.0;
   double csc = (avg > 0.0) ? (h[1] - l[1]) / avg : 1.0;
   string CSC = (csc > InpCSCHigh) ? "High" : ((csc < InpCSCLow) ? "Low" : "Middle");
   //--- 7) UDF
   int udf = 0;
   for(int i = 1; i <= 28; i++)
      if(Sgn(c[i] - c[i + 1]) != Sgn(c[i + 1] - c[i + 2])) udf++;
   string UDF = (udf >= InpUDFHigh) ? "High" : "Low";
   //--- 8) MMD (channel height / ATR)
   double mmd = height / a;
   string MMD = (mmd > InpMMDHigh) ? "High" : ((mmd < InpMMDLow) ? "Low" : "Middle");

   string pat = (dir > 0) ? "BO_L" : "BO_S";
   string row = TimeStr(iTime(_Symbol, Period(), 0)) + "," + _Symbol + "," + g_tf + "," + pat + "," +
                PP + "," + SRD + "," + VR + "," + PC + "," + TL + "," + CSC + "," + UDF + "," + MMD + "," +
                DoubleToString(pp, 4) + "," +
                DoubleToString(res == DBL_MAX ? -1.0 : res, 1) + "," +
                DoubleToString(sup == DBL_MAX ? -1.0 : sup, 1) + "," +
                DoubleToString(vr, 3) + "," + DoubleToString(pc, 2) + "," + DoubleToString(csc, 3) + "," +
                IntegerToString(udf) + "," + DoubleToString(mmd, 3) + "," +
                DoubleToString(entry, _Digits) + "," + DoubleToString(sl, _Digits) + "," +
                DoubleToString(tp, _Digits) + "," + DoubleToString(slDist / g_pip, 1) + "," +
                DoubleToString((tk.ask - tk.bid) / g_pip, 2);
   return(row);
  }

//+------------------------------------------------------------------+
double VolumeRate()
  {
   int      k   = (int)MathMax(1, 7200 / PeriodSeconds(Period()));
   datetime t0  = iTime(_Symbol, Period(), 0);
   double   cur = BarsVolume(1, k);
   double   sum = 0.0;
   int      cnt = 0;
   for(int d = 1; d <= 40 && cnt < 20; d++)
     {
      int sh = iBarShift(_Symbol, Period(), t0 - d * 86400, true);
      if(sh < 0) continue;
      double v = BarsVolume(sh + 1, k);
      if(v > 0.0) { sum += v; cnt++; }
     }
   if(cnt == 0 || sum <= 0.0)
      return(0.0);
   return(cur / (sum / cnt));
  }

double BarsVolume(const int startPos, const int count)
  {
   long v[];
   int got = CopyTickVolume(_Symbol, Period(), startPos, count, v);
   if(got <= 0)
      return(0.0);
   double s = 0.0;
   for(int i = 0; i < got; i++) s += (double)v[i];
   return(s);
  }

double CommissionPips()
  {
   double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return(0.0);
   double pipValue = tv * g_pip / ts;
   return(2.0 * InpCommPerLotSide / pipValue);
  }

bool IsPivotHigh(const double &arr[], const int i, const int s, const int n)
  {
   if(i - s < 1 || i + s >= n) return(false);
   for(int j = 1; j <= s; j++)
      if(arr[i] <= arr[i - j] || arr[i] < arr[i + j]) return(false);
   return(true);
  }

bool IsPivotLow(const double &arr[], const int i, const int s, const int n)
  {
   if(i - s < 1 || i + s >= n) return(false);
   for(int j = 1; j <= s; j++)
      if(arr[i] >= arr[i - j] || arr[i] > arr[i + j]) return(false);
   return(true);
  }

void RemoveTrade(const int i)
  {
   int last = ArraySize(g_trades) - 1;
   if(i != last)
     {
      g_trades[i] = g_trades[last];
      g_rows[i]   = g_rows[last];
     }
   ArrayResize(g_trades, last);
   ArrayResize(g_rows, last);
  }

int BarsPerDay()        { return((int)MathMax(1, 86400 / PeriodSeconds(Period()))); }
int Sgn(const double x) { return(x > 0.0 ? 1 : (x < 0.0 ? -1 : 0)); }

string TimeStr(const datetime t)
  {
   string s = TimeToString(t, TIME_DATE | TIME_MINUTES);
   StringReplace(s, ".", "-");
   return(s);
  }
//+------------------------------------------------------------------+
