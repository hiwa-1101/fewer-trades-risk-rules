//+------------------------------------------------------------------+
//| MW2021_EA.mq5 - MetaTrader 5 version (core in MW2021_Core.mqh)    |
//+------------------------------------------------------------------+
#property copyright "Reconstruction of the 2021 M/W risk-rule paper"
#property version   "1.00"
#include "MW2021_Core.mqh"
int  OnInit(){ return CoreInit(); }
void OnTick(){ CoreTick(); }
