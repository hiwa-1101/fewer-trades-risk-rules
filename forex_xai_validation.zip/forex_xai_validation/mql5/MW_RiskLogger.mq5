//+------------------------------------------------------------------+
//|                                                 MW_RiskLogger.mq5 |
//|  Research logger for: "Explainable Association-Rule Mining for    |
//|  Pre-Trade Stop-Loss Risk Detection in Forex Reversal Patterns"   |
//|                                                                   |
//|  - Detects M (double-top) and W (double-bottom) patterns          |
//|  - Opens a VIRTUAL trade on the first candle close beyond the     |
//|    neckline (no real orders are sent)                             |
//|  - SL = 2nd peak/trough +/- buffer, TP = RR x SL distance         |
//|  - Exits are evaluated on every tick (use "real ticks" mode)      |
//|  - Computes the 8 descriptors of Table I at the breakout candle   |
//|  - Writes one CSV row per closed trade to Common\Files            |
//+------------------------------------------------------------------+
#property copyright   "H. Hassanzadeh, E. Khezri"
#property version     "1.10"
#property description "Research logger - virtual trades only, no orders are sent."

//--- pattern detection
input int    InpSwingStrength   = 3;      // Swing pivot strength (bars on each side)
input int    InpMinSeparation   = 5;      // Min bars between the two peaks/troughs
input int    InpMaxSeparation   = 60;     // Max bars between the two peaks/troughs
input double InpPeakTolATR      = 0.5;    // |extreme1 - extreme2| <= x * ATR
input double InpMinHeightATR    = 1.0;    // Pattern height >= x * ATR
input int    InpMaxBarsToBreak  = 20;     // Breakout must occur within N bars of 2nd extreme
input int    InpATRPeriod       = 14;     // ATR period
//--- trade simulation
input double InpSLBufferPips    = 2.0;    // SL buffer beyond 2nd peak/trough (pips)
input int    InpExitVariant     = 1;      // Exit: 0=RR1.0 1=RR1.5 2=RR2.0 3=RR3.0 4=measured move
input double InpCommPerLotSide  = 3.0;    // Commission, account currency per lot per side
//--- descriptors (Table I)
input int    InpSRStrength      = 10;     // Pivot strength for support/resistance levels
input int    InpSRDays          = 5;      // S/R look-back (trading days)
input double InpSRThresholdPips = 20.0;   // "Near" S/R threshold (pips)
input double InpVRHigh          = 1.20;   // VR >= x  -> High
input double InpPCThreshold     = 0.20;   // |PC| > x -> Bullish / Bearish
input double InpCSCHigh         = 1.50;   // CSC > x  -> High
input double InpCSCLow          = 0.80;   // CSC < x  -> Low
input int    InpUDFHigh         = 14;     // UDF >= x -> High
input double InpMMDHigh         = 1.00;   // MMD > x  -> High
input double InpMMDLow          = 0.50;   // MMD < x  -> Low
input string InpFilePrefix      = "MW_trades";

struct VTrade
  {
   int               dir;        // +1 = buy (W), -1 = sell (M)
   double            entry;
   double            sl;
   double            tp;
   double            slPips;
  };

VTrade   g_trades[];
string   g_rows[];
double   g_pip     = 0.0;
int      g_atr     = INVALID_HANDLE;
int      g_file    = INVALID_HANDLE;
datetime g_lastBar = 0;
datetime g_usedM   = 0;
datetime g_usedW   = 0;
string   g_tf      = "";
int      g_logged  = 0;
double   g_sumR    = 0.0;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_pip = (_Digits == 3 || _Digits == 5) ? 10.0 * _Point : _Point;
   g_tf  = StringSubstr(EnumToString(Period()), 7);            // "M5", "M15", "H1"
   g_atr = iATR(_Symbol, Period(), InpATRPeriod);
   if(g_atr == INVALID_HANDLE)
      return(INIT_FAILED);
   if(InpExitVariant < 0 || InpExitVariant > 4)
      return(INIT_PARAMETERS_INCORRECT);
   string name = InpFilePrefix + "_" + _Symbol + "_" + g_tf + "_X" + IntegerToString(InpExitVariant) +
                 "_B" + DoubleToString(InpSLBufferPips, 0) + ".csv";
   g_file = FileOpen(name, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(g_file == INVALID_HANDLE)
     {
      Print("Cannot open ", name, ", error ", GetLastError());
      return(INIT_FAILED);
     }
   FileWriteString(g_file,
      "open_time,pair,timeframe,pattern,PP,SRD,VR,PC,TL,CSC,UDF,MMD,"
      "pp_raw,res_dist_pips,sup_dist_pips,vr_raw,pc_raw,csc_raw,udf_raw,mmd_raw,"
      "entry,sl,tp,sl_pips,spread_pips,exit_time,outcome,gross_pips,net_pips,exit_variant,sl_buffer\r\n");
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//--- optimisation criterion: sum of net R-multiples of closed trades
double OnTester()
  {
   return(g_sumR);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   PrintFormat("%s %s: %d trades logged, %d still open at end of test (not logged)",
               _Symbol, g_tf, g_logged, ArraySize(g_trades));
   if(g_file != INVALID_HANDLE)
      FileClose(g_file);
   if(g_atr != INVALID_HANDLE)
      IndicatorRelease(g_atr);
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   MqlTick tk;
   if(!SymbolInfoTick(_Symbol, tk))
      return;
   ManageTrades(tk);
   datetime bt = iTime(_Symbol, Period(), 0);
   if(bt == g_lastBar)
      return;
   g_lastBar = bt;
   int s = InpSwingStrength;
   int n = InpMaxBarsToBreak + InpMaxSeparation + 2 * s + 5;
   int needSR = InpSRDays * BarsPerDay() + InpSRStrength + 2;
   if(Bars(_Symbol, Period()) < MathMax(n, needSR) + 10)
      return;
   double h[], l[], c[], atr[];
   ArraySetAsSeries(h, true);
   ArraySetAsSeries(l, true);
   ArraySetAsSeries(c, true);
   if(CopyHigh(_Symbol, Period(), 0, n, h) != n ||
      CopyLow(_Symbol, Period(), 0, n, l) != n ||
      CopyClose(_Symbol, Period(), 0, n, c) != n)
      return;
   if(CopyBuffer(g_atr, 0, 1, 1, atr) != 1 || atr[0] <= 0.0)
      return;
   TryPattern(-1, h, l, c, n, atr[0], tk);   // M pattern -> sell
   TryPattern(+1, h, l, c, n, atr[0], tk);   // W pattern -> buy
  }

//+------------------------------------------------------------------+
//| Exit check for all open virtual trades                           |
//+------------------------------------------------------------------+
void ManageTrades(const MqlTick &tk)
  {
   for(int i = ArraySize(g_trades) - 1; i >= 0; i--)
     {
      string outcome = "";
      double exitPx  = 0.0;
      if(g_trades[i].dir < 0)                 // sell closes at Ask
        {
         if(tk.ask >= g_trades[i].sl)      { outcome = "SL"; exitPx = tk.ask; }
         else if(tk.ask <= g_trades[i].tp) { outcome = "TP"; exitPx = tk.ask; }
        }
      else                                    // buy closes at Bid
        {
         if(tk.bid <= g_trades[i].sl)      { outcome = "SL"; exitPx = tk.bid; }
         else if(tk.bid >= g_trades[i].tp) { outcome = "TP"; exitPx = tk.bid; }
        }
      if(outcome == "")
         continue;
      double gross = g_trades[i].dir * (exitPx - g_trades[i].entry) / g_pip;
      double net   = gross - CommissionPips();
      FileWriteString(g_file, g_rows[i] + "," + TimeStr(tk.time) + "," + outcome + "," +
                      DoubleToString(gross, 1) + "," + DoubleToString(net, 1) + "," +
                      IntegerToString(InpExitVariant) + "," + DoubleToString(InpSLBufferPips, 1) + "\r\n");
      g_sumR += net / g_trades[i].slPips;
      FileFlush(g_file);
      g_logged++;
      RemoveTrade(i);
     }
  }

//+------------------------------------------------------------------+
//| Generic double-top / double-bottom detector.                     |
//| For W patterns the series are mirrored (e = -low, q = -high,     |
//| k = -close) so the same double-top logic applies.                |
//+------------------------------------------------------------------+
void TryPattern(const int dir, const double &h[], const double &l[], const double &c[],
                const int n, const double a, const MqlTick &tk)
  {
   int s = InpSwingStrength;
   double e[], q[], k[];
   ArrayResize(e, n);
   ArrayResize(q, n);
   ArrayResize(k, n);
   for(int i = 0; i < n; i++)
     {
      e[i] = (dir < 0) ? h[i] : -l[i];
      q[i] = (dir < 0) ? l[i] : -h[i];
      k[i] = (dir < 0) ? c[i] : -c[i];
     }
   //--- 2nd extreme: most recent confirmed swing
   int p2 = -1;
   for(int i = s + 1; i <= InpMaxBarsToBreak && i < n - s; i++)
      if(IsPivotHigh(e, i, s, n)) { p2 = i; break; }
   if(p2 < 0)
      return;
   datetime t2 = iTime(_Symbol, Period(), p2);
   if(t2 == ((dir < 0) ? g_usedM : g_usedW))
      return;
   //--- 1st extreme: previous swing
   int p1 = -1;
   for(int i = p2 + InpMinSeparation; i <= p2 + InpMaxSeparation && i < n - s; i++)
      if(IsPivotHigh(e, i, s, n)) { p1 = i; break; }
   if(p1 < 0)
      return;
   //--- neckline: deepest opposite extreme between the two swings
   int nk = p2 + 1;
   for(int i = p2 + 1; i < p1; i++)
      if(q[i] < q[nk]) nk = i;
   double neck = q[nk];
   if(MathAbs(e[p1] - e[p2]) > InpPeakTolATR * a)
      return;
   if(MathMin(e[p1], e[p2]) - neck < InpMinHeightATR * a)
      return;
   //--- 2nd extreme not exceeded after it formed
   for(int i = 1; i < p2; i++)
      if(e[i] > e[p2]) return;
   //--- breakout candle (shift 1) is the FIRST close beyond the neckline
   if(k[1] >= neck)
      return;
   for(int i = 2; i <= p2; i++)
      if(k[i] < neck) return;
   if(dir < 0) g_usedM = t2; else g_usedW = t2;
   //--- virtual trade
   double ext2   = (dir < 0) ? e[p2] : -e[p2];
   double entry  = (dir < 0) ? tk.bid : tk.ask;
   double sl     = ext2 - dir * InpSLBufferPips * g_pip;   // M: above 2nd peak, W: below 2nd trough
   double slDist = dir * (entry - sl);
   if(slDist <= 0.0)
      return;
   double height = MathMax(e[p1], e[p2]) - neck;            // full pattern height
   double neckPx = (dir < 0) ? neck : -neck;
   double tp;
   if(InpExitVariant == 4)                                    // classic measured-move target
      tp = neckPx + dir * height;
   else
     {
      double rr[4] = {1.0, 1.5, 2.0, 3.0};
      tp = entry + dir * rr[InpExitVariant] * slDist;
     }
   if(dir * (tp - entry) <= 0.0)
      return;
   string row = BuildRow(dir, a, height, entry, sl, tp, slDist, tk);
   if(row == "")
      return;
   int sz = ArraySize(g_trades);
   ArrayResize(g_trades, sz + 1);
   ArrayResize(g_rows, sz + 1);
   g_trades[sz].dir   = dir;
   g_trades[sz].entry = entry;
   g_trades[sz].sl    = sl;
   g_trades[sz].tp    = tp;
   g_trades[sz].slPips = slDist / g_pip;
   g_rows[sz]         = row;
  }

//+------------------------------------------------------------------+
//| The 8 descriptors of Table I, computed at the breakout candle    |
//+------------------------------------------------------------------+
string BuildRow(const int dir, const double a, const double height, const double entry,
                const double sl, const double tp, const double slDist, const MqlTick &tk)
  {
   int n24  = BarsPerDay();
   int sr   = InpSRStrength;
   int need = MathMax(InpSRDays * n24 + sr + 2, 40);
   double o[], h[], l[], c[];
   ArraySetAsSeries(o, true);
   ArraySetAsSeries(h, true);
   ArraySetAsSeries(l, true);
   ArraySetAsSeries(c, true);
   if(CopyOpen(_Symbol, Period(), 0, need, o) != need ||
      CopyHigh(_Symbol, Period(), 0, need, h) != need ||
      CopyLow(_Symbol, Period(), 0, need, l) != need ||
      CopyClose(_Symbol, Period(), 0, need, c) != need)
      return("");
   double c1 = c[1];
   //--- 1) Price position in the last 24 h
   double hi = h[1], lo = l[1];
   for(int i = 1; i <= n24; i++) { hi = MathMax(hi, h[i]); lo = MathMin(lo, l[i]); }
   double pp = (hi > lo) ? (c1 - lo) / (hi - lo) : 0.5;
   string PP = (pp < 0.333) ? "Lower" : ((pp > 0.667) ? "Upper" : "Middle");
   //--- 2) Distance to nearest swing resistance / support of the last N trading days
   double res = DBL_MAX, sup = DBL_MAX;
   for(int i = sr + 1; i <= InpSRDays * n24 && i < need - sr; i++)
     {
      if(IsPivotHigh(h, i, sr, need) && h[i] > c1) res = MathMin(res, (h[i] - c1) / g_pip);
      if(IsPivotLow(l, i, sr, need)  && l[i] < c1) sup = MathMin(sup, (c1 - l[i]) / g_pip);
     }
   bool nearR = (res <= InpSRThresholdPips), nearS = (sup <= InpSRThresholdPips);
   string SRD = "N";
   if(nearR && (!nearS || res <= sup)) SRD = "R";
   else if(nearS)                       SRD = "S";
   //--- 3) Volume rate (tick volume, last 2 h vs same 2-h session of previous 20 trading days)
   double vr = VolumeRate();
   string VR = (vr >= InpVRHigh) ? "High" : "Low";
   //--- 4) Predominant colour of the last 10 candles
   int bull = 0, bear = 0;
   for(int i = 1; i <= 10; i++) { if(c[i] > o[i]) bull++; else if(c[i] < o[i]) bear++; }
   double pc = (bull - bear) / 10.0;
   string PC = (pc > InpPCThreshold) ? "Bullish" : ((pc < -InpPCThreshold) ? "Bearish" : "Neutral");
   //--- 5) Trend line: last 20 candles split into 3 segments (7/7/6), oldest -> newest
   string TL = (c[14] > o[20] ? "U" : "D");
   TL += (c[7] > o[13] ? "U" : "D");
   TL += (c[1] > o[6] ? "U" : "D");
   //--- 6) Candle size change: breakout range / mean range of previous 14 candles
   double avg = 0.0;
   for(int i = 2; i <= 15; i++) avg += h[i] - l[i];
   avg /= 14.0;
   double csc = (avg > 0.0) ? (h[1] - l[1]) / avg : 1.0;
   string CSC = (csc > InpCSCHigh) ? "High" : ((csc < InpCSCLow) ? "Low" : "Middle");
   //--- 7) Up/down frequency: direction reversals of close-to-close moves, last 30 candles
   int udf = 0;
   for(int i = 1; i <= 28; i++)
      if(Sgn(c[i] - c[i + 1]) != Sgn(c[i + 1] - c[i + 2])) udf++;
   string UDF = (udf >= InpUDFHigh) ? "High" : "Low";
   //--- 8) Max-min domain: pattern height / ATR
   double mmd = height / a;
   string MMD = (mmd > InpMMDHigh) ? "High" : ((mmd < InpMMDLow) ? "Low" : "Middle");

   string pat = (dir < 0) ? "M" : "W";
   string row = TimeStr(iTime(_Symbol, Period(), 0)) + "," + _Symbol + "," + g_tf + "," + pat + "," +
                PP + "," + SRD + "," + VR + "," + PC + "," + TL + "," + CSC + "," + UDF + "," + MMD + "," +
                DoubleToString(pp, 4) + "," +
                DoubleToString(res == DBL_MAX ? -1.0 : res, 1) + "," +
                DoubleToString(sup == DBL_MAX ? -1.0 : sup, 1) + "," +
                DoubleToString(vr, 3) + "," + DoubleToString(pc, 2) + "," + DoubleToString(csc, 3) + "," +
                IntegerToString(udf) + "," + DoubleToString(mmd, 3) + "," +
                DoubleToString(entry, _Digits) + "," + DoubleToString(sl, _Digits) + "," +
                DoubleToString(tp, _Digits) + "," + DoubleToString(slDist / g_pip, 1) + "," +
                DoubleToString((tk.ask - tk.bid) / g_pip, 2);
   return(row);
  }

//+------------------------------------------------------------------+
//--- VR: tick volume of the last 2 h of TRADING bars vs. the same 2-h window
//--- (same clock time) on the previous 20 trading days. Bar-based, so the
//--- weekend gap does not produce artificially low values on Monday opens.
double VolumeRate()
  {
   int      k   = (int)MathMax(1, 7200 / PeriodSeconds(Period()));   // bars in 2 h
   datetime t0  = iTime(_Symbol, Period(), 0);
   double   cur = BarsVolume(1, k);
   double   sum = 0.0;
   int      cnt = 0;
   for(int d = 1; d <= 40 && cnt < 20; d++)
     {
      int sh = iBarShift(_Symbol, Period(), t0 - d * 86400, true);   // bar at same clock time
      if(sh < 0) continue;                                           // weekend / holiday
      double v = BarsVolume(sh + 1, k);
      if(v > 0.0) { sum += v; cnt++; }
     }
   if(cnt == 0 || sum <= 0.0)
      return(0.0);
   return(cur / (sum / cnt));
  }

double BarsVolume(const int startPos, const int count)
  {
   long v[];
   int got = CopyTickVolume(_Symbol, Period(), startPos, count, v);
   if(got <= 0)
      return(0.0);
   double s = 0.0;
   for(int i = 0; i < got; i++) s += (double)v[i];
   return(s);
  }

//+------------------------------------------------------------------+
double CommissionPips()
  {
   double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return(0.0);
   double pipValue = tv * g_pip / ts;           // account currency per pip per 1 lot
   return(2.0 * InpCommPerLotSide / pipValue);  // round-turn commission in pips
  }

bool IsPivotHigh(const double &arr[], const int i, const int s, const int n)
  {
   if(i - s < 1 || i + s >= n) return(false);
   for(int j = 1; j <= s; j++)
      if(arr[i] <= arr[i - j] || arr[i] < arr[i + j]) return(false);
   return(true);
  }

bool IsPivotLow(const double &arr[], const int i, const int s, const int n)
  {
   if(i - s < 1 || i + s >= n) return(false);
   for(int j = 1; j <= s; j++)
      if(arr[i] >= arr[i - j] || arr[i] > arr[i + j]) return(false);
   return(true);
  }

void RemoveTrade(const int i)
  {
   int last = ArraySize(g_trades) - 1;
   if(i != last)
     {
      g_trades[i] = g_trades[last];
      g_rows[i]   = g_rows[last];
     }
   ArrayResize(g_trades, last);
   ArrayResize(g_rows, last);
  }

int BarsPerDay()   { return((int)MathMax(1, 86400 / PeriodSeconds(Period()))); }
int Sgn(const double x) { return(x > 0.0 ? 1 : (x < 0.0 ? -1 : 0)); }

string TimeStr(const datetime t)
  {
   string s = TimeToString(t, TIME_DATE | TIME_MINUTES);
   StringReplace(s, ".", "-");
   return(s);
  }
//+------------------------------------------------------------------+
