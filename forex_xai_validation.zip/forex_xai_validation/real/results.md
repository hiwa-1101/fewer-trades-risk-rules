# Out-of-sample results (test from 2025-01-01)

|                                |   taken |   rejected |   SL |   TP |   TP_lost |   SL_avoided |   SL_rate_% |   win_rate_% |   net_PF |   net_pips |   max_DD_pips |   expectancy_pips |
|:-------------------------------|--------:|-----------:|-----:|-----:|----------:|-------------:|------------:|-------------:|---------:|-----------:|--------------:|------------------:|
| Unfiltered                     |    4407 |          0 | 2760 | 1647 |         0 |            0 |       62.63 |        37.37 |    0.838 |   -10238.3 |       10888.8 |            -2.323 |
| Single-indicator (TL=UDD)      |    3840 |        567 | 2388 | 1452 |       195 |          372 |       62.19 |        37.81 |    0.869 |    -7158.3 |        7752.1 |            -1.864 |
| Apriori-only                   |     105 |       4302 |   69 |   36 |      1611 |         2691 |       65.71 |        34.29 |    0.874 |     -344.8 |        1167.4 |            -3.284 |
| CART-only                      |    4200 |        207 | 2629 | 1571 |        76 |          131 |       62.6  |        37.4  |    0.835 |    -9817.1 |       10370.1 |            -2.337 |
| Hybrid Apriori-CART (proposed) |    4407 |          0 | 2760 | 1647 |         0 |            0 |       62.63 |        37.37 |    0.838 |   -10238.3 |       10888.8 |            -2.323 |
| Random filter (mean of 1000)   |    4407 |          0 | 2760 | 1647 |         0 |            0 |       62.63 |        37.37 |    0.838 |   -10238.3 |       10888.8 |            -2.323 |

## Per pair x timeframe

| pair   | timeframe   |   trades |   SL_before |   SL_after |   pips_before |   pips_after |
|:-------|:------------|---------:|------------:|-----------:|--------------:|-------------:|
| EURUSD | H1          |       87 |          59 |         59 |       -1347.8 |      -1347.8 |
| EURUSD | H4          |       21 |          12 |         12 |          55.9 |         55.9 |
| EURUSD | M15         |      330 |         210 |        210 |        -787   |       -787   |
| EURUSD | M5          |     1113 |         694 |        694 |       -1554.4 |      -1554.4 |
| GBPUSD | H1          |       61 |          32 |         32 |         514.7 |        514.7 |
| GBPUSD | H4          |       20 |          13 |         13 |        -160   |       -160   |
| GBPUSD | M15         |      344 |         212 |        212 |        -402.1 |       -402.1 |
| GBPUSD | M5          |     1084 |         697 |        697 |       -2471.3 |      -2471.3 |
| USDJPY | H1          |       63 |          40 |         40 |       -1071.3 |      -1071.3 |
| USDJPY | H4          |       22 |          14 |         14 |        -739.8 |       -739.8 |
| USDJPY | M15         |      318 |         191 |        191 |          49.1 |         49.1 |
| USDJPY | M5          |      944 |         586 |        586 |       -2324.3 |      -2324.3 |

## Summary

```
{
  "min_conf_used": 0.672,
  "leaf_purity_used": 0.711,
  "n_train": 8286,
  "n_test": 4407,
  "MMD_tertile_cuts_train": [
    2.103,
    2.583
  ],
  "n_rules_apriori": 89,
  "n_rules_final": 0,
  "cart_params": {
    "max_depth": 6,
    "min_samples_leaf": 20
  },
  "cart_cv_auc": 0.5124,
  "SL_count_reduction_%": 0.0,
  "SL_rate_change_pp": 0.0,
  "net_pips_change_%": 0.0,
  "CI95_SL_reduction_%": [
    0.0,
    0.0
  ],
  "CI95_net_pips_change_%": [
    0.0,
    0.0
  ],
  "p_vs_random_SL": 1.0,
  "p_vs_random_net_pips": 1.0,
  "wilcoxon_daily": {
    "note": "too few non-zero paired days for Wilcoxon"
  }
}
```

## Final rule base


