# When Fewer Trades Look Like Better Rules — code and data

Code, trade logs, and results for the paper
**“When Fewer Trades Look Like Better Rules: A Pre-Registered Validation of Explainable Risk Rules for Forex Decision Support”**
(H. Hassanzadeh, E. Khezri; submitted to CSICC 2026).

Every number in the paper is produced by the scripts below from the MetaTrader 5 trade logs in this repository.

## Repository layout

```
mql5/                 MetaTrader 5 Expert Advisors (virtual trades, real ticks, CSV logging to Common\Files)
  MW_RiskLogger.mq5     Testbed B: M/W reversal rule (v1.10)
  TF_XAI_Logger.mq5     Testbed B: Donchian trend rule (v1.00)
  MW2021_EA.mq5         Testbed A: re-implemented M/W experts of the earlier (2021) study (v1.00)
  MW2021_Core.mqh       shared core of MW2021_EA (pattern, 8 original descriptors, rules R1–R5, logging)
mql4/                 the same Testbed A expert for MetaTrader 4 (same core file)
scripts/              Python analysis (Python 3.13; see requirements.txt)
real/, tf/            Testbed B raw logs: MW_trades_<pair>_<tf>.csv, TF_trades_<pair>_<tf>.csv (2023–2025)
mw_all.csv, tf_all.csv  Testbed B merged logs (12,693 reversal and 10,920 trend trades)
r2021/                Testbed A, 2021 (M expert in r2021/, W expert in r2021/W/), M5
r2325/W/              Testbed A, 2023–2025, M5, both experts (pre-registered confirmation data)
rtf/                  Testbed A, 2023–2025, M15 and H1, both experts (secondary analysis)
results/              all JSON/CSV outputs and figures; preregistration_R1_2026-11-01.md
```

## How the trade logs were generated

MetaTrader 5 Strategy Tester, *Every tick based on real ticks*, broker tick history (Alpari MT5), commission USD 3 per lot
per side (Testbed B, deducted in the log), default EA inputs.

| Testbed | EA | Symbols | Timeframes | Period | Notes |
|---|---|---|---|---|---|
| B | MW_RiskLogger, TF_XAI_Logger | EURUSD, GBPUSD, USDJPY | M5, M15, H1, H4 | 2023-01-01 – 2025-12-31 | `merge_mt5_logs.py` merges the per-symbol files |
| A | MW2021_EA (`InpExpert` 0 = M, 1 = W; `InpRule` = 0) | EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD | M5 (M15, H1 secondary) | 2021-05-21 – 2021-07-21 and 2023-01-01 – 2025-12-31 | Optimization mode “All symbols selected in Market Watch”; deposit 10,000 (1,000,000 for M15/H1 and the three re-run cells) |

All undocumented settings of the 2021 study are inputs of `MW2021_Core.mqh` with their default values; they were fixed
before any run and never changed. The hypothesis for the 2023–2025 confirmation was recorded in
`results/preregistration_R1_2026-11-01.md` (a dated internal record) before the 2023–2025 runs were made.

## Reproducing the paper

Run from the repository root, e.g. `python scripts/replication2021.py`. Outputs go to `results/`.

| Paper item | Script(s) | Output | Runtime (approx.) |
|---|---|---|---|
| Table III, 2021 rows | `replication2021.py` | `replication2021.json` | minutes |
| Table III, 2023–25 rows (pre-registered) | `confirm2325.py` | `confirm2325.json` | minutes |
| M15/H1 secondary check | `confirm_tf.py` | `confirm_tf.json` | minutes |
| Fig. 2 | `fig6_case.py` | `fig6_case.png` | < 1 min |
| Section IV-C (60 filters, SPA / reality check) | `final_numbers.py`, `spa_test.py` | `final_numbers.json`, `spa.json` | minutes |
| Table IV (performance, block CIs, Holm) | `compare.py` → `stats_step3.py` | `combined_trades.csv`, `step3_stats.json` | minutes |
| Table V, Fig. 3 (planted effects, permutation null) | `robustness2.py main`, `robustness2.py brl`, `robustness.py` (27-point grid), then `summarize_robustness.py`, `figs.py` | `robustness2_main.csv`, `robustness2_brl.csv`, `robustness_runs.csv`, `r1_summary.json`, `brl_summary.json`, `sensitivity_summary.csv`, `fig5_sensitivity.png` | several hours |
| Table VI, walk-forward, logistic filter | `final_tables.py`, `step_r3.py`, `logit_quarterly.py`, `step4.py` | `final_tables.json`, `r3.json`, `logit_quarterly.json`, `step4.json` | ~1 hour |
| AUCs, costs | `final_numbers.py` | `final_numbers.json` | minutes |
| Fig. 1 | `figs.py` | `fig1_workflow.png` | < 1 min |

`mw2021_tables.py` prints Testbed A results in the table layout of the original 2021 study (with/without rule per pair).
`forex_rule_analysis.py` and `opt_select.py` are the stand-alone rule-mining and exit-selection tools used during
development.

## Notes

* Random seeds are fixed in every script; bootstrap and permutation results are reproducible.
* Bayesian rule lists (imodels) return rule items as `X_k`; scripts map them back to descriptor names. The BRL rows of
  `robustness_runs.csv` come from an earlier run without this mapping and are **not** used in the paper (the paper's BRL
  results come from `robustness2_brl.csv`).
* Three Testbed A cells (W on USDCHF and USDCAD, M on USDCAD) were first run with a small simulated deposit and stopped
  trading when it was exhausted; they were re-run with a deposit of 1,000,000, and only the complete logs are included.
* Trades are virtual: the EAs log entries and exits at real tick prices but do not send orders, so all signals are logged
  independently.

## Requirements

See `requirements.txt` (tested with Python 3.13). MetaTrader 5 (build with `iHigh`/`iLow`… series functions) is needed
only to regenerate the logs.

## Contact

Edris Khezri (corresponding author), Edris.khezri@iau.ac.ir
