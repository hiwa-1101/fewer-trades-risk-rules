//+------------------------------------------------------------------+
//| MW2021_Core.mqh  -  reconstruction of the 2021 paper's method     |
//| M/W (Gartley-like, no Fibonacci) experts, 8 original metrics,     |
//| 5 risk rules, per-trade CSV log.  Compiles in MQL4 and MQL5.      |
//| Every numeric value not stated in the paper is an INPUT and is    |
//| listed in README_FA.md as an assumption.                          |
//+------------------------------------------------------------------+
input int    InpExpert        = 0;     // 0 = M expert (sell), 1 = W expert (buy)
input int    InpRule          = 0;     // 0 = normal, 1..5 = apply rule k, 9 = all five rules
input bool   InpCeilIsBottom  = true;  // label of lowest 30% of 24h range: true = "Ceil", false = "Roof"
input double InpRiskMoney     = 100;   // money risked per trade (paper: ~100 per SL)
input double InpFixedLot      = 0;     // >0: fixed lot instead of risk money
input double InpRR            = 1.0;   // TP distance / SL distance (paper tables imply 1:1)
input int    InpPivot         = 5;     // swing strength (paper: ZigZag 5)
input double InpMinLegATR     = 2.0;   // first leg X->A at least this many ATR(14)
input double InpMinLeg2ATR    = 0.5;   // leg B->C at least this many ATR(14)
input int    InpMaxBarsAfterC = 20;    // entry must happen within N bars after C
input double InpEntryDepth    = 0.0;   // 0 = entry at break of B; >0 = entry at C -/+ depth*(A-X)
input double InpSLBufferPips  = 2.0;   // SL beyond C
input double InpSRNearATR     = 1.0;   // S/R "near" distance in ATR(14)
input double InpCSCRatio      = 2.0;   // big/small candle range ratio
input int    InpMagicBase     = 2021;
input string InpLogPrefix     = "MW2021";

//---------------- price helpers (iX functions exist in MQL4 and MQL5)
double O(int i){ return iOpen(_Symbol,_Period,i); }
double H(int i){ return iHigh(_Symbol,_Period,i); }
double L(int i){ return iLow(_Symbol,_Period,i); }
double C(int i){ return iClose(_Symbol,_Period,i); }
double V(int i){ return (double)iVolume(_Symbol,_Period,i); }
datetime T(int i){ return iTime(_Symbol,_Period,i); }
double Pip(){ return (_Digits==3 || _Digits==5) ? 10*_Point : _Point; }
int    Magic(){ return InpMagicBase*10 + InpExpert; }
int    BarsPer(int seconds){ return MathMax(1, seconds / PeriodSeconds()); }

double ATRv(int s,int n)
{
   double sum=0;
   for(int i=s;i<s+n;i++){ double pc=C(i+1); sum+=MathMax(H(i),pc)-MathMin(L(i),pc); }
   return sum/n;
}

bool IsPH(int i,int s)
{
   double h=H(i);
   for(int k=1;k<=s;k++){ if(H(i-k)>=h) return false; if(H(i+k)>h) return false; }
   return true;
}
bool IsPL(int i,int s)
{
   double l=L(i);
   for(int k=1;k<=s;k++){ if(L(i-k)<=l) return false; if(L(i+k)<l) return false; }
   return true;
}

//---------------- alternating swing list, newest first
int    pvIdx[80]; int pvType[80]; double pvPrice[80]; int pvN=0;
void BuildPivots(int start,int lookback)
{
   pvN=0;
   for(int i=start;i<start+lookback && pvN<80;i++)
   {
      bool ph=IsPH(i,InpPivot), pl=IsPL(i,InpPivot);
      if(ph==pl) continue;                       // none, or outside bar (ambiguous)
      int t = ph ? 1 : -1; double p = ph ? H(i) : L(i);
      if(pvN>0 && pvType[pvN-1]==t)
      {  // two swings of the same type in a row: keep the more extreme one
         if((t==1 && p>pvPrice[pvN-1]) || (t==-1 && p<pvPrice[pvN-1])){ pvIdx[pvN-1]=i; pvPrice[pvN-1]=p; }
         continue;
      }
      pvIdx[pvN]=i; pvType[pvN]=t; pvPrice[pvN]=p; pvN++;
   }
}

//---------------- pattern detection on the last closed bar (shift 1)
// M (sell): X low, A high, B low, C high, then decline below level -> sell.  W is the mirror (buy).
datetime gLastPatternC=0;
bool DetectSignal(int dir,double &entryLevel,double &cPrice,datetime &cTime)
{
   BuildPivots(InpPivot+1,400);
   int want = (dir<0) ? 1 : -1;                  // type of C: high for M, low for W
   int c=-1;
   for(int k=0;k<pvN;k++) if(pvType[k]==want){ c=k; break; }
   if(c<0 || c+3>=pvN) return false;
   double Cp=pvPrice[c], Bp=pvPrice[c+1], Ap=pvPrice[c+2], Xp=pvPrice[c+3];
   int ci=pvIdx[c];
   if(ci-1>InpMaxBarsAfterC) return false;
   double atr=ATRv(1,14); if(atr<=0) return false;
   double s=(dir<0)?1.0:-1.0;                    // s*(price) turns W into M geometry
   if(s*(Ap-Xp) < InpMinLegATR*atr) return false; // significant first move
   if(!(s*Bp > s*Xp)) return false;               // retracement does not pass the origin
   if(!(s*Bp < s*Ap)) return false;
   if(!(s*Cp < s*Ap)) return false;               // second move stops before A
   if(s*(Cp-Bp) < InpMinLeg2ATR*atr) return false;
   double level = (InpEntryDepth<=0) ? Bp : Cp - s*InpEntryDepth*MathAbs(Ap-Xp);
   if(!(s*C(1) < s*level)) return false;          // close beyond the level now ...
   for(int i=2;i<ci;i++) if(s*C(i) < s*level) return false;   // ... for the first time
   for(int i=1;i<ci;i++){ double ext=(dir<0)?H(i):L(i); if(s*ext > s*Cp) return false; } // C not exceeded
   if(T(ci)==gLastPatternC) return false;         // one trade per pattern
   entryLevel=level; cPrice=Cp; cTime=T(ci);
   return true;
}

//---------------- the eight metrics of the 2021 paper (computed at shift 1)
string mPP,mVR,mPC,mTL,mUDF,mCSC,mSRD,mMMD; int mDays=0;

int CountPivots(int s0,int len)
{
   int n=0;
   for(int i=s0+InpPivot;i<s0+len;i++) if(IsPH(i,InpPivot) || IsPL(i,InpPivot)) n++;
   return n;
}

void ComputeMetrics(int dir)
{
   double atr=ATRv(1,14);
   int bpd=BarsPer(86400), n2h=BarsPer(7200);
   // 1) Market price position: 24h range split 30 / 40 / 30
   double hi=H(1), lo=L(1);
   for(int i=1;i<=bpd;i++){ hi=MathMax(hi,H(i)); lo=MathMin(lo,L(i)); }
   double pos=(hi>lo)?(C(1)-lo)/(hi-lo):0.5;
   string bottom=InpCeilIsBottom?"Ceil":"Roof", top=InpCeilIsBottom?"Roof":"Ceil";
   mPP = (pos<0.30)?bottom:((pos>0.70)?top:"Middle");
   // 2) Volume rate (tick volume, last 2h vs same 2h on the previous 20 trading days)  and
   // 5) Up-down frequency (swings in last 100 candles vs same window on previous 20 days)
   double vcur=0; for(int i=1;i<=n2h;i++) vcur+=V(i);
   int ucur=CountPivots(1,100);
   double vs=0, us=0; int cnt=0; datetime t1=T(1);
   for(int d=1; d<=40 && cnt<20; d++)
   {
      datetime td=t1-d*86400;
      int k=iBarShift(_Symbol,_Period,td,false);
      if(k<1 || k+110>=iBars(_Symbol,_Period)) continue;
      if(MathAbs((double)(T(k)-td))>3600) continue;            // weekend / holiday
      double v=0; for(int i=k;i<k+n2h;i++) v+=V(i);
      vs+=v; us+=CountPivots(k,100); cnt++;
   }
   mDays=cnt;
   mVR  = (cnt>0 && vcur>=vs/cnt) ? "High" : "Low";
   mUDF = (cnt>0 && ucur>=us/cnt) ? "High" : "Low";
   // 3) Predominant color: every second candle of the last 10 (5 candles)
   int g=0,r=0;
   for(int i=1;i<=9;i+=2){ if(C(i)>O(i)) g++; else if(C(i)<O(i)) r++; }
   mPC = (g>r)?"Green":((r>g)?"Red":((C(1)>=C(10))?"Green":"Red"));
   // 4) Trend pattern of the last 20 candles (3 characters)
   double top20=MathMax(O(20),C(20)), bot20=MathMin(O(20),C(20));
   int up=0,dn=0;
   for(int i=19;i>=1;i--){ if(MathMax(O(i),C(i))>top20) up++; if(MathMin(O(i),C(i))<bot20) dn++; }
   string c1=(up>2)?"U":"D", c2=(dn>2)?"D":"U";
   double diff=C(1)-C(20);
   string c3=(MathAbs(diff)<=0.1*atr)?"E":((diff>0)?"U":"D");
   mTL=c1+c2+c3;
   // 6) Candle size changes: big-next-to-small pairs in last 20 candles vs previous 200
   int pc=0, ph=0;
   for(int i=1;i<20;i++){ double a=H(i)-L(i), b=H(i+1)-L(i+1); if(MathMax(a,b)>=InpCSCRatio*MathMax(MathMin(a,b),_Point)) pc++; }
   for(int i=21;i<220;i++){ double a=H(i)-L(i), b=H(i+1)-L(i+1); if(MathMax(a,b)>=InpCSCRatio*MathMax(MathMin(a,b),_Point)) ph++; }
   double avg=ph*19.0/199.0;
   mCSC = (pc>1.25*avg)?"High":((pc<0.75*avg)?"Low":"Middle");
   // 7) Support / resistance distance (swing levels of the last 24h)
   double res=-1, sup=-1, px=C(1);
   for(int i=InpPivot+1;i<=bpd;i++)
   {
      if(IsPH(i,InpPivot) && H(i)>px && (res<0 || H(i)<res)) res=H(i);
      if(IsPL(i,InpPivot) && L(i)<px && (sup<0 || L(i)>sup)) sup=L(i);
   }
   double near=InpSRNearATR*atr, dR=(res>0)?res-px:1e9, dS=(sup>0)?px-sup:1e9;
   mSRD = (dR<=near && dR<=dS)?"R":((dS<=near)?"S":((dR<=near)?"R":"N"));
   // 8) Max-min domain: range of last 10 candles vs mean 10-candle range of last 100
   double r10=H(1)-L(1), sum=0;
   for(int w=0; w<10; w++)
   {
      double h=H(1+10*w), l=L(1+10*w);
      for(int i=1+10*w;i<=10+10*w;i++){ h=MathMax(h,H(i)); l=MathMin(l,L(i)); }
      if(w==0) r10=h-l;
      sum+=h-l;
   }
   mMMD = (r10>sum/10.0)?"High":"Low";
}

//---------------- the five rules of Table 5 (labels as in the paper)
bool RuleFires(int k)
{
   switch(k)
   {
      case 1: return (mPP=="Ceil" && mSRD!="N");
      case 2: return (mPP=="Middle" && mSRD!="N" && mMMD=="High");
      case 3: return (mPP=="Middle" && mSRD=="N" && mTL=="UDU" && mMMD=="Low");
      case 4: return (mPP=="Ceil" && mSRD!="N" && mCSC=="High");
      case 5: return (mPP=="Ceil" && mTL=="UUU" && mSRD=="N" && mCSC=="Middle");
   }
   return false;
}
bool Blocked()
{
   if(InpRule>=1 && InpRule<=5) return RuleFires(InpRule);
   if(InpRule==9){ for(int k=1;k<=5;k++) if(RuleFires(k)) return true; }
   return false;
}

//---------------- CSV log (Common\Files)
string LogName()
{
   return StringFormat("%s_%s_%s_%s_R%d.csv",InpLogPrefix,_Symbol,StringSubstr(EnumToString((ENUM_TIMEFRAMES)_Period),7),
                       (InpExpert==0)?"M":"W",InpRule);
}
string gRow="";
void LogInit()
{
   int h=FileOpen(LogName(),FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_COMMON,',');
   if(h==INVALID_HANDLE) return;
   FileWrite(h,"open_time","symbol","tf","expert","rule_run","entry","sl","tp","lots","PP","VR","PC","TL","UDF","CSC","SRD","MMD",
             "hist_days","R1","R2","R3","R4","R5","outcome","profit","close_time");
   FileClose(h);
}
string MetricsRow(double entry,double sl,double tp,double lots)
{
   return StringFormat("%s,%s,%s,%s,%d,%s,%s,%s,%.2f,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d,%d,%d,%d",
      TimeToString(T(0),TIME_DATE|TIME_MINUTES),_Symbol,StringSubstr(EnumToString((ENUM_TIMEFRAMES)_Period),7),
      (InpExpert==0)?"M":"W",InpRule,DoubleToString(entry,_Digits),DoubleToString(sl,_Digits),DoubleToString(tp,_Digits),lots,
      mPP,mVR,mPC,mTL,mUDF,mCSC,mSRD,mMMD,mDays,
      (int)RuleFires(1),(int)RuleFires(2),(int)RuleFires(3),(int)RuleFires(4),(int)RuleFires(5));
}
void LogWrite(string row,string outcome,double profit,datetime ct)
{
   int h=FileOpen(LogName(),FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON);
   if(h==INVALID_HANDLE) return;
   FileSeek(h,0,SEEK_END);
   FileWriteString(h,row+","+outcome+","+DoubleToString(profit,2)+","+TimeToString(ct,TIME_DATE|TIME_MINUTES)+"\r\n");
   FileClose(h);
}

double CalcLots(double slDist)
{
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP), vmin=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN),
          vmax=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double lots=InpFixedLot;
   if(lots<=0)
   {
      double tv=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE), ts=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      if(tv<=0 || ts<=0 || slDist<=0) return 0;
      lots=InpRiskMoney/(slDist/ts*tv);
   }
   lots=MathFloor(lots/step)*step;
   return MathMax(vmin,MathMin(vmax,lots));
}

//================ platform-specific trading ==========================
#ifdef __MQL5__
#include <Trade/Trade.mqh>
CTrade gTrade;
double AskP(){ return SymbolInfoDouble(_Symbol,SYMBOL_ASK); }
double BidP(){ return SymbolInfoDouble(_Symbol,SYMBOL_BID); }
bool HasOpen()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
      if(PositionGetSymbol(i)==_Symbol && PositionGetInteger(POSITION_MAGIC)==Magic()) return true;
   return false;
}
bool SendOrder(int dir,double lots,double sl,double tp)
{
   gTrade.SetExpertMagicNumber(Magic());
   gTrade.SetDeviationInPoints(30);
   return dir>0 ? gTrade.Buy(lots,_Symbol,0,sl,tp,InpLogPrefix) : gTrade.Sell(lots,_Symbol,0,sl,tp,InpLogPrefix);
}
double ClosedProfit(datetime from,datetime &ct)
{
   double p=0; ct=TimeCurrent();
   if(!HistorySelect(from,TimeCurrent()+60)) return 0;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong d=HistoryDealGetTicket(i);
      if(HistoryDealGetString(d,DEAL_SYMBOL)!=_Symbol || HistoryDealGetInteger(d,DEAL_MAGIC)!=Magic()) continue;
      p+=HistoryDealGetDouble(d,DEAL_PROFIT)+HistoryDealGetDouble(d,DEAL_SWAP)+HistoryDealGetDouble(d,DEAL_COMMISSION);
      if(HistoryDealGetInteger(d,DEAL_ENTRY)==DEAL_ENTRY_OUT) ct=(datetime)HistoryDealGetInteger(d,DEAL_TIME);
   }
   return p;
}
#else
double AskP(){ RefreshRates(); return Ask; }
double BidP(){ RefreshRates(); return Bid; }
int gTicket=-1;
bool HasOpen()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES) && OrderSymbol()==_Symbol && OrderMagicNumber()==Magic()) return true;
   return false;
}
bool SendOrder(int dir,double lots,double sl,double tp)
{
   gTicket=OrderSend(_Symbol,dir>0?OP_BUY:OP_SELL,lots,dir>0?AskP():BidP(),3,sl,tp,InpLogPrefix,Magic(),0,clrNONE);
   return gTicket>0;
}
double ClosedProfit(datetime from,datetime &ct)
{
   ct=TimeCurrent();
   if(gTicket<=0 || !OrderSelect(gTicket,SELECT_BY_TICKET)) return 0;
   ct=OrderCloseTime();
   return OrderProfit()+OrderSwap()+OrderCommission();
}
#endif

//================ shared event logic =================================
bool     gInTrade=false;
datetime gOpenTime=0, gLastBar=0;

int CoreInit()
{
   LogInit();
   return INIT_SUCCEEDED;
}

void CoreTick()
{
   // 1) closed trade -> log outcome
   if(gInTrade && !HasOpen())
   {
      datetime ct; double p=ClosedProfit(gOpenTime,ct);
      LogWrite(gRow,(p>0)?"TP":"SL",p,ct);
      gInTrade=false;
   }
   // 2) new bar -> look for a signal on the closed bar
   datetime t0=T(0);
   if(t0==gLastBar) return;
   gLastBar=t0;
   if(iBars(_Symbol,_Period)<700 || gInTrade || HasOpen()) return;
   int dir=(InpExpert==0)?-1:1;
   double level,cPrice; datetime cTime;
   if(!DetectSignal(dir,level,cPrice,cTime)) return;
   gLastPatternC=cTime;
   double entry=(dir>0)?AskP():BidP();
   double sl=(dir>0)?cPrice-InpSLBufferPips*Pip():cPrice+InpSLBufferPips*Pip();
   double dist=MathAbs(entry-sl);
   double minDist=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point+(AskP()-BidP());
   if(dist<=minDist || (dir>0 && sl>=entry) || (dir<0 && sl<=entry)) return;
   double tp=(dir>0)?entry+InpRR*dist:entry-InpRR*dist;
   sl=NormalizeDouble(sl,_Digits); tp=NormalizeDouble(tp,_Digits);
   double lots=CalcLots(dist);
   ComputeMetrics(dir);
   string row=MetricsRow(entry,sl,tp,lots);
   if(Blocked()){ LogWrite(row,"BLOCKED",0,T(0)); return; }
   if(lots<=0) return;
   if(SendOrder(dir,lots,sl,tp)){ gRow=row; gInTrade=true; gOpenTime=TimeCurrent(); }
}
