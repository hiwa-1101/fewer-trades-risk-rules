//+------------------------------------------------------------------+
//| MW2021_EA.mq4 - MetaTrader 4 version (core in MW2021_Core.mqh)    |
//+------------------------------------------------------------------+
#property copyright "Reconstruction of the 2021 M/W risk-rule paper"
#property version   "1.00"
#property strict
#include "MW2021_Core.mqh"
int  OnInit(){ return CoreInit(); }
void OnTick(){ CoreTick(); }
