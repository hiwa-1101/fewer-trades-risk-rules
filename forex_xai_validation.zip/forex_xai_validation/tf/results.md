# Out-of-sample results (test from 2025-01-01)

|                                |   taken |   rejected |   SL |   TP |   TP_lost |   SL_avoided |   SL_rate_% |   win_rate_% |   net_PF |   net_pips |   max_DD_pips |   expectancy_pips |
|:-------------------------------|--------:|-----------:|-----:|-----:|----------:|-------------:|------------:|-------------:|---------:|-----------:|--------------:|------------------:|
| Unfiltered                     |    3522 |          0 | 2436 | 1086 |         0 |            0 |       69.17 |        30.83 |    0.836 |    -4912.4 |        5560.1 |            -1.395 |
| Single-indicator (MMD=High)    |    2374 |       1148 | 1617 |  757 |       329 |          819 |       68.11 |        31.89 |    0.886 |    -2289.2 |        2799.9 |            -0.964 |
| Apriori-only                   |     369 |       3153 |  249 |  120 |       966 |         2187 |       67.48 |        32.52 |    0.866 |     -643.8 |        1221.1 |            -1.745 |
| CART-only                      |    3440 |         82 | 2381 | 1059 |        27 |           55 |       69.22 |        30.78 |    0.833 |    -4926.9 |        5578.9 |            -1.432 |
| Hybrid Apriori-CART (proposed) |    3522 |          0 | 2436 | 1086 |         0 |            0 |       69.17 |        30.83 |    0.836 |    -4912.4 |        5560.1 |            -1.395 |
| Random filter (mean of 1000)   |    3522 |          0 | 2436 | 1086 |         0 |            0 |       69.17 |        30.83 |    0.836 |    -4912.4 |        5560.1 |            -1.395 |

## Per pair x timeframe

| pair   | timeframe   |   trades |   SL_before |   SL_after |   pips_before |   pips_after |
|:-------|:------------|---------:|------------:|-----------:|--------------:|-------------:|
| EURUSD | H1          |       73 |          47 |         47 |         -47.3 |        -47.3 |
| EURUSD | H4          |       27 |          19 |         19 |        -335.4 |       -335.4 |
| EURUSD | M15         |      277 |         185 |        185 |        -286.3 |       -286.3 |
| EURUSD | M5          |      812 |         579 |        579 |       -1096.2 |      -1096.2 |
| GBPUSD | H1          |       73 |          41 |         41 |         640.6 |        640.6 |
| GBPUSD | H4          |       24 |          13 |         13 |         209.1 |        209.1 |
| GBPUSD | M15         |      277 |         189 |        189 |        -339.6 |       -339.6 |
| GBPUSD | M5          |      779 |         541 |        541 |       -1005.8 |      -1005.8 |
| USDJPY | H1          |       66 |          44 |         44 |         132.8 |        132.8 |
| USDJPY | H4          |       24 |          15 |         15 |        -269.1 |       -269.1 |
| USDJPY | M15         |      275 |         193 |        193 |        -658.9 |       -658.9 |
| USDJPY | M5          |      815 |         570 |        570 |       -1856.3 |      -1856.3 |

## Summary

```
{
  "min_conf_used": 0.772,
  "leaf_purity_used": 0.802,
  "n_train": 7398,
  "n_test": 3522,
  "MMD_tertile_cuts_train": [
    4.907,
    7.091
  ],
  "n_rules_apriori": 85,
  "n_rules_final": 0,
  "cart_params": {
    "max_depth": 6,
    "min_samples_leaf": 80
  },
  "cart_cv_auc": 0.5225,
  "SL_count_reduction_%": 0.0,
  "SL_rate_change_pp": 0.0,
  "net_pips_change_%": 0.0,
  "CI95_SL_reduction_%": [
    0.0,
    0.0
  ],
  "CI95_net_pips_change_%": [
    0.0,
    0.0
  ],
  "p_vs_random_SL": 1.0,
  "p_vs_random_net_pips": 1.0,
  "wilcoxon_daily": {
    "note": "too few non-zero paired days for Wilcoxon"
  }
}
```

## Final rule base


