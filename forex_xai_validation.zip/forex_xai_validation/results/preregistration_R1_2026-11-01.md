# Pre-registered confirmation of 2021 Rule 1 (recorded 2026-11-01, before any 2022-2025 MW2021_EA run)
EA: MW2021_EA v1.00, default inputs (InpCeilIsBottom=true, RR=1, pivot 5, MinLegATR 2.0, ...), MT5 Alpari, M5, real ticks.
Pairs: EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD; experts M and W; InpRule=0 (rules evaluated from logs).
Period: 2023-01-01 .. 2025-12-31 (no data from this period has been examined with this EA).
Primary hypothesis H1: trades on which Rule 1 (PP=Ceil AND SRD!=N) fires have a lower mean R than the others, so that
  removing them raises mean R of accepted trades: day-block bootstrap 95% CI of delta R (kept minus all) above 0 AND
  one-sided random-blocking p < 0.05 (same number of blocked trades per pair x expert cell).
Secondary (Holm over R2, R4): same test. R3, R5 fire too rarely to test.
Reported regardless of outcome. Basis: 2021 test month, R1 delta R = +0.062 [0.006, 0.119], random p = 0.022 (4 rules tested).
